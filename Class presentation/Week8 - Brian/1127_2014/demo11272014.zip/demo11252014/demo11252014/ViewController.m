//
//  ViewController.m
//  demo11252014
//
//  Created by Brian on 2014/11/25.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "ViewController.h"

// 3rd Party Library
#import "MBProgressHUD.h"
#import "AFNetworking.h"

@interface ViewController () <MBProgressHUDDelegate, UITextFieldDelegate>
{
    MBProgressHUD  *progressHUD;
    NSMutableArray *dataSource;

    NSTimer        *_timer;
    double         timerNumber;

}
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UIButton *startTimer;
@property (weak, nonatomic) IBOutlet UIButton *pauseTimer;
@property (weak, nonatomic) IBOutlet UILabel *timerLabel;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"測試";

//    UIBarButtonItem *preButton = [[UIBarButtonItem alloc] initWithTitle:@"上一頁" style:UIBarButtonItemStylePlain target:self action:@selector(back:)];
//
//    // Set the properties
//    [preButton setTitleTextAttributes:
//     [NSDictionary dictionaryWithObjectsAndKeys:
//    [UIColor whiteColor],  NSForegroundColorAttributeName, [UIFont systemFontOfSize:12], NSFontAttributeName,
//      nil] forState:UIControlStateNormal];
//
//    // Set the left navigation button
//    self.navigationItem.leftBarButtonItem = preButton;

    UIButton *a1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [a1 setFrame:CGRectMake(0.0f, 0.0f, 46.0f, 29.0f)];
    [a1 addTarget:self action:@selector(enterEditMode:) forControlEvents:UIControlEventTouchUpInside];
    [a1 setTitle:@"編輯" forState:UIControlStateNormal];
    [a1.titleLabel setFont:[UIFont systemFontOfSize:13.0f]];
    [a1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    a1.titleLabel.textColor = [UIColor blackColor];
    UIBarButtonItem *right1Button = [[UIBarButtonItem alloc] initWithCustomView:a1];

    UIButton *a2 = [UIButton buttonWithType:UIButtonTypeCustom];
    //[a2 setFrame:CGRectMake(0.0f, 0.0f, 52.0f, 32.0f)];
    [a2 setFrame:CGRectMake(0.0f, 0.0f, 46.0f, 29.0f)];
    [a2 addTarget:self action:@selector(leaveEditMode:) forControlEvents:UIControlEventTouchUpInside];
    [a2 setTitle:@"結束" forState:UIControlStateNormal];
    [a2.titleLabel setFont:[UIFont systemFontOfSize:13.0f]];
    [a2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    a2.titleLabel.textColor = [UIColor blackColor];
    UIBarButtonItem *right2Button = [[UIBarButtonItem alloc] initWithCustomView:a2];

    self.navigationItem.rightBarButtonItems = @[right1Button, right2Button];

    UIImage *leftIcon = [[UIImage imageNamed:@"btn_nav_back"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithImage:leftIcon
            style:UIBarButtonItemStylePlain
            target:self
            action:@selector(back:)];

    self.navigationItem.leftBarButtonItem = leftButton;

    NSInteger a = 32;
    NSLog(@"%ld", a);
    NSLog(@"%p", &a);

    [self.startTimer.layer setCornerRadius:10.0f];
    [self.startTimer.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [self.startTimer.layer setBorderWidth:2.0f];

    [self.pauseTimer.layer setCornerRadius:10.0f];
    [self.pauseTimer.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [self.pauseTimer.layer setBorderWidth:2.0f];

    timerNumber = 0.0f;

    dataSource = [NSMutableArray arrayWithCapacity:0];
    [self getRemoteURL];

    [self.textField becomeFirstResponder];
}

- (void)enterEditMode:(id)sender
{
    NSLog(@"enterEditMode");
}

- (void)leaveEditMode:(id)sender
{
    NSLog(@"leaveEditMode");
}


- (IBAction)completeEnter:(id)sender
{
    NSString *final = [self.textField.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSLog(@"Enter:%@", final);

    [self.textField resignFirstResponder];
}

- (IBAction)startTheTimer:(id)sender
{
    double interval = 1.0f;
    _timer = [NSTimer scheduledTimerWithTimeInterval:interval
                                              target:self
                                            selector:@selector(timerEvent:)
                                            userInfo:nil
                                             repeats:true];

}

- (IBAction)stopTheTimer:(id)sender
{
    [_timer invalidate];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:@"已停止" delegate:self cancelButtonTitle:@"確認" otherButtonTitles:nil];
    [alert show];
}

- (void)timerEvent:(NSTimer *)timer
{
    timerNumber += 1.0f;
    self.timerLabel.text = [NSString stringWithFormat:@"%.2f", timerNumber];

    // NSLog(@"timer event is invoked : %f", timerNumber);
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    NSLog(@"textFieldShouldBeginEditing");
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    NSLog(@"textFieldShouldEndEditing");
    return YES;
}

- (void)getRemoteURL
{
    [self initializeProgressHUD:@"載入中..."];

    // Prepare the HTTP Client
    AFHTTPClient *httpClient =
    [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:@"http://106.187.98.65/"]];

    NSMutableURLRequest *request = [httpClient requestWithMethod:@"GET"
                                                            path:@"api/v1/AlphaCampTest.php"
                                                      parameters:nil];

    // Set the opration
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];

    // Set the callback block
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"Completed!");
        NSLog(@"We are in antoher thread.");
        [progressHUD hide:YES];

        NSString *tmp = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        // Test Log
        NSLog(@"Response: %@", tmp);
        NSData* rawData = [tmp dataUsingEncoding:NSUTF8StringEncoding];
        NSError* e;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:rawData options:NSJSONReadingMutableContainers error:&e];

        NSString *RC = [NSString stringWithFormat:@"%@",  [dict objectForKey:@"RC"]];
        NSString *RM = [NSString stringWithFormat:@"%@", [dict objectForKey:@"RM"]];

        NSArray* listData = dict[@"result"];
        NSLog(@"listData:%@", listData);
        NSInteger arrayLength = [listData count];

        NSLog(@"Array Length: %ld", arrayLength);

        if (arrayLength > 0) {
            [dataSource removeAllObjects];

            for (int i = 0 ; i < arrayLength; i++) {
                NSDictionary *innerDict = listData[i];
                [dataSource addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                [innerDict objectForKey:@"announcement_version"],   @"announcement_version",
                [innerDict objectForKey:@"current_time"],  @"current_time",
                [innerDict objectForKey:@"waiting_time"],  @"waiting_time",
                [innerDict objectForKey:@"ios_version"],  @"ios_version",
                [innerDict objectForKey:@"android_version"],  @"android_version", nil]];

            }
        }

        NSLog(@"final result:%@", dataSource);
        NSLog(@"Table Reload");
        [self.tableView reloadData];

//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:RM delegate:self cancelButtonTitle:@"確認" otherButtonTitles:nil];
//        [alert show];

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error");
    }];

    // Start the opration
    [operation start];
}

- (void)back:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:@"前一頁" delegate:self cancelButtonTitle:@"確認" otherButtonTitles:nil];
    [alert show];
}

- (IBAction)complete:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:@"完成" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles:nil];
    [alert show];
}

#pragma mark - UITableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSLog(@"numberOfSectionsInTableView");
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"heightForRowAtIndexPath");
    return 60.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"numberOfRowsInSection");
    NSLog(@"Source count:%ld",  [dataSource count]);
    return [dataSource count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"cellForRowAtIndexPath");

    static NSString *requestIdentifier = @"GeneralCell";
    UITableViewCell *cell;

    cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                      reuseIdentifier:requestIdentifier];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.textColor =
        [UIColor colorWithRed:241.0f/255.0f green:244.0f/255.0f blue:239.0f/255.0f alpha:1.0f];
        cell.backgroundColor = [UIColor clearColor];

        cell.textLabel.font  = [UIFont fontWithName: @"AvenirNextCondensed-Bold" size: 14.0];

        cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:12.0f];

        cell.selectionStyle =UITableViewCellSelectionStyleGray;
        cell.textLabel.text = dataSource[indexPath.row][@"current_time"];
    }


    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(230, 10, 80, 40)];
    [button setTitle:@"Update" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont fontWithName: @"AvenirNextCondensed-Bold" size: 12.0];
    [button setBackgroundColor:[UIColor clearColor]];
    button.tag = indexPath.row;

    [button addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [cell.contentView addSubview:button];

    [button.layer setCornerRadius:10.0f];
    [button.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [button.layer setBorderWidth:2.0f];

    UIButton *openTELBtn = [[UIButton alloc]initWithFrame:CGRectMake(140, 10, 80, 40)];
    [openTELBtn setTitle:@"Open" forState:UIControlStateNormal];
    openTELBtn.titleLabel.font = [UIFont fontWithName: @"AvenirNextCondensed-Bold" size: 12.0];
    [openTELBtn setBackgroundColor:[UIColor clearColor]];
    openTELBtn.tag = indexPath.row;

    [openTELBtn addTarget:self action:@selector(openWeb:) forControlEvents:UIControlEventTouchUpInside];
    [cell.contentView addSubview:openTELBtn];

    [openTELBtn.layer setCornerRadius:10.0f];
    [openTELBtn.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [openTELBtn.layer setBorderWidth:2.0f];

    // cell.separatorInset = UIEdgeInsetsMake(0.0f, cell.frame.size.width, 0.0f, 0.0f);
    return cell;
}

- (void)openWeb:(id)sender
{
    NSString *url = [NSString stringWithFormat:@"http://%@", self.textField.text];
    NSLog(@"Ready to open %@", url);
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"You pressed: %d %d", indexPath.section, indexPath.row);
}

- (void)buttonPressed:(id)sender
{
    UIButton *button = (UIButton *)sender;
    NSLog(@"You pressed the button %d", button.tag);
}

- (void)initializeProgressHUD:(NSString *)msg
{
    if (progressHUD)
        [progressHUD removeFromSuperview];

    progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:progressHUD];
    progressHUD.dimBackground = NO;
    progressHUD.delegate = self;
    progressHUD.labelText = msg;

    progressHUD.margin = 20.f;
    progressHUD.yOffset = 10.f;

    progressHUD.removeFromSuperViewOnHide = YES;
    [progressHUD show:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
