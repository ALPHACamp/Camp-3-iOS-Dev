//
//  ViewController.m
//  demo11282014
//
//  Created by Brian on 2014/11/28.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UIGestureRecognizerDelegate>
{
    UITextField             *memberNameText;
    UITextField             *passwordText;

    IBOutlet UIButton       *loginButton;
    IBOutlet UIButton       *forgetButton;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    self.tableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];

    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];

    [loginButton.layer setCornerRadius:5.0f];

    // Init input text field
    memberNameText = [[UITextField alloc]initWithFrame:CGRectMake(40, 0, 275, 40)];
    memberNameText.textColor = [UIColor darkGrayColor];
    memberNameText.delegate = self;
    memberNameText.textAlignment = NSTextAlignmentLeft;
    memberNameText.tag = 101;
    memberNameText.font = [UIFont fontWithName: @"STHeitiTC-Medium" size: 13.0];
    memberNameText.autocapitalizationType = UITextAutocapitalizationTypeNone;
    memberNameText.placeholder = @"Email";

    passwordText = [[UITextField alloc]initWithFrame:CGRectMake(40, 0, 275, 40)];
    passwordText.textColor = [UIColor blackColor];
    passwordText.delegate = self;
    passwordText.textAlignment = NSTextAlignmentLeft;
    [passwordText setSecureTextEntry:YES];
    passwordText.tag = 102;
    passwordText.font = [UIFont fontWithName: @"STHeitiTC-Medium" size: 13.0];
    passwordText.placeholder = @"6-12位英數字，不含標點符號";

    UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    [gestureRecognizer setDelegate:self];

    [self.view addGestureRecognizer:gestureRecognizer];
}

- (void)hideKeyboard
{
    [self.view endEditing:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *requestIdentifier = @"LoginCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier];

    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:requestIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.textLabel.font  = [UIFont fontWithName: @"STHeitiTC-Medium" size: 14.0];
        cell.detailTextLabel.font = [UIFont fontWithName: @"STHeitiTC-Light" size: 14.0];
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.textLabel.textAlignment = NSTextAlignmentLeft;
        cell.textLabel.textColor = [UIColor colorWithRed:121/255.0 green:121/255.0 blue:121/255.0 alpha:1];
        cell.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }

    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"";
            [cell.contentView addSubview:memberNameText];
            break;
        case 1:
            cell.textLabel.text = @"";
            [cell.contentView addSubview:passwordText];
            break;
        default:
            break;
    }

    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
