//
//  ViewController.m
//  demo11252014
//
//  Created by Brian on 2014/11/25.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "ViewController.h"

// 3rd Party Library
#import "AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"測試";

    UIBarButtonItem *preButton = [[UIBarButtonItem alloc] initWithTitle:@"上一頁" style:UIBarButtonItemStylePlain target:self action:@selector(back:)];

    // Set the properties
    [preButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
    [UIColor whiteColor],  NSForegroundColorAttributeName, [UIFont systemFontOfSize:12], NSFontAttributeName,
      nil] forState:UIControlStateNormal];

    // Set the left navigation button
    self.navigationItem.leftBarButtonItem = preButton;
    [self getRemoteURL];
}

- (void)getRemoteURL
{
    // Prepare the HTTP Client
    AFHTTPClient *httpClient =
    [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:@"http://106.187.98.65/"]];

    NSMutableURLRequest *request = [httpClient requestWithMethod:@"GET"
                                                            path:@"api/v1/AlphaCampTest.php"
                                                      parameters:nil];

    // Set the opration
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];

    // Set the callback block
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {

        NSString *tmp = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];

        // Test Log
        NSLog(@"Response: %@", tmp);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error");
    }];

    // Start the opration
    [operation start];
}

- (void)back:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:@"前一頁" delegate:self cancelButtonTitle:@"確認" otherButtonTitles:nil];
    [alert show];
}

- (IBAction)complete:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:@"完成" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles:nil];
    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
