//
//  ViewController.m
//  Demo1126_Pihan
//
//  Created by PiHan Hsu on 2014/11/26.
//  Copyright (c) 2014年 PiHan Hsu. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>
{
    NSArray * dataSource;
    NSArray * detailDataSource;
    
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;


@end

@implementation ViewController



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"測試";
    dataSource = [NSArray arrayWithObjects: @"Message1", @"Message2", @"Message3", @"Message4", @"Message5", @"Message6",@"Message7", @"Message8", @"Message9",@"Message10",nil];
    
    detailDataSource = [NSArray arrayWithObjects: @"Abstract1", @"Abstract2", @"Abstract3", @"Abstract4", @"Abstract5", @"Abstract6",@"Abstract7", @"Abstract8", @"Abstract9",@"Abstract10",nil];
    
    UIBarButtonItem *preButton = [[UIBarButtonItem alloc] initWithTitle:@"上一頁" style: UIBarButtonItemStylePlain target:self action:@selector(back:)];
    
    [preButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, [UIFont systemFontOfSize:12], NSFontAttributeName, nil] forState: UIControlStateNormal];
    
    self.navigationItem.leftBarButtonItem =preButton;
    
    
    NSLog(@"Datasource: %@", dataSource);
    [self getRemoteURL];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1 ;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 60.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *requestIdentifier = @"HelloCell";
    static NSString *requestIdentifier2 = @"HelloCell2";
    
    UITableViewCell *cell;
    switch (indexPath.section) {
        case 0:{
            cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:requestIdentifier];
                cell.textLabel.textColor = [UIColor whiteColor];
                cell.backgroundColor = [UIColor clearColor];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                cell.detailTextLabel.textColor = [UIColor colorWithRed:241.0f/255.0f green:244.0f/255.0f blue:239.0f/255.0f alpha:1.0f];
                cell.textLabel.font = [UIFont fontWithName:@"AppleSDGothicNeo-Bold" size: 20.f];
                cell.detailTextLabel.font = [UIFont fontWithName:@"Avenir-LightOblique" size: 12.f];
                
            }
        }
            break;
        case 1:{
            cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier2];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:requestIdentifier2];
                cell.textLabel.textColor = [UIColor whiteColor];
                cell.backgroundColor = [UIColor clearColor];
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                cell.detailTextLabel.textColor = [UIColor colorWithRed:241.0f/255.0f green:244.0f/255.0f blue:239.0f/255.0f alpha:1.0f];
                cell.textLabel.font = [UIFont fontWithName:@"AppleSDGothicNeo-Bold" size: 20.f];
                cell.detailTextLabel.font = [UIFont fontWithName:@"Avenir-LightOblique" size: 12.f];
                
            }
        }
        default:
            break;
    }
    
    cell.textLabel.text = dataSource [indexPath.row];
    cell.detailTextLabel.text = detailDataSource [indexPath.row];
    
    NSString *title;
    switch (indexPath.section) {
        case 0:
            title = @"download";
            break;
        case 1:
            title =@"upload";
            break;
            
        default:
            break;
    }
    
    UIButton *button= [[ UIButton alloc] initWithFrame:CGRectMake(220, 15, 80, 30)];
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont fontWithName:@"AppleSDGothicNeo-Bold" size: 14.f];
    [button setBackgroundColor:[UIColor clearColor]];
    [button addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    button.tag =indexPath.row;
    //button.layer.cornerRadius = 25.0f;
    [button.layer setCornerRadius:4.0f];
    [button.layer setBorderColor:[[UIColor whiteColor]CGColor]];
    [button.layer setBorderWidth:1.0f];
    [cell.contentView addSubview:button];
    
    return cell;
}

-(void)buttonPressed: (id)sender
{
    UIButton *button = (UIButton *)sender;
    NSLog(@"You Pressed the button %d",(int)button.tag);
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"You Pressed: %d, %d", (int)indexPath.section, (int)indexPath.row);
    
}

- (void)back:(id)sender
{
    
    UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"提醒" message:@"前一頁" delegate:self cancelButtonTitle:@"確認" otherButtonTitles:nil, nil];
    
    [alert show];
    
}


-(IBAction)complete:(id)sender{
    UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"提醒" message:@"完成" delegate:self cancelButtonTitle:@"關閉" otherButtonTitles:nil, nil];
    
    [alert show];
    
}


- (void) getRemoteURL
{
    AFHTTPClient *httpClient=
    [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:@"http://106.187.98.65/"]];
    NSMutableURLRequest *request = [httpClient requestWithMethod:@"GET" path:@"api/v1/AlphaCampTest.php" parameters:nil];
    
    
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSString*tmp = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"Response: %@", tmp);
        
    }failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error");
        
    }];
    
    [operation start];
}

@end
