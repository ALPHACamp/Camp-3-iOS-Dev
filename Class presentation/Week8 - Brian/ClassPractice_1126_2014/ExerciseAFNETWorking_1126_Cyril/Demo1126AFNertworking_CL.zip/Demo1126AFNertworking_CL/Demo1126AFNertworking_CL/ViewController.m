//
//  ViewController.m
//  Demo1126AFNertworking_CL
//
//  Created by Cyrilshanway on 2014/11/26.
//  Copyright (c) 2014年 Cyrilshanway. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title =@"KKTix test";
    
    UIBarButtonItem *preBtn = [[UIBarButtonItem alloc] initWithTitle:@"上一頁" style:(UIBarButtonItemStylePlain) target:self action:@selector(back:)];
    
    
    // Set the properties
    [preBtn setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor whiteColor],  NSForegroundColorAttributeName, [UIFont systemFontOfSize:12], NSFontAttributeName,
      nil] forState:UIControlStateNormal];
    
    self.navigationItem.leftBarButtonItem = preBtn;
    
    [self getRemoteURL];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - AFNetworking
-(void)getRemoteURL{
    
    //1. 準備HTTP Client
    AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:@"http://106.187.98.65/"]];
    NSMutableURLRequest *request = [httpClient requestWithMethod:@"GET"
                                                            path:@"api/v1/AlphaCampTest.php" parameters:nil];
    //2.準備operation
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    
    //3.準備callback block
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSString *tmp = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"Response: %@",tmp);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error");
    }];
    
    //4. Start傳輸
    [operation start];
}

#pragma mark - UITableView Delegate
//分類
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
//欄位高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60.0;
}
//要顯示幾個欄位
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //兩個section
    /*
    static NSString *requestIdentifier = @"HelloCell";
    static NSString *requestIdentifier2 = @"HelloCell2";
    
    UITableViewCell *cell;
    
    switch (indexPath.section) {
        case 0:{
            cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier];
            
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                              reuseIdentifier:requestIdentifier];
                cell.textLabel.textColor = [UIColor purpleColor];
                cell.detailTextLabel.textColor =[UIColor brownColor];
                cell.backgroundColor = [UIColor clearColor];
                
                cell.textLabel.font  = [UIFont fontWithName: @"AvenirNextCondensed-Bold" size: 14.0];
                
                cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:12.0f];
                
                cell.selectionStyle =UITableViewCellSelectionStyleGray;
            }
        }
            break;
            
        case 1: {
            cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier2];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                              reuseIdentifier:requestIdentifier2];
                cell.textLabel.textColor = [UIColor blueColor];
                cell.detailTextLabel.textColor =
                [UIColor orangeColor];
                cell.backgroundColor = [UIColor clearColor];
                
                cell.textLabel.font  = [UIFont fontWithName: @"AvenirNextCondensed-Bold" size: 14.0];
                
                cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:12.0f];
                
                cell.selectionStyle =UITableViewCellSelectionStyleGray;
            }
        }
            break;
    }
    */
    // UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier];
    
    //cell.textLabel.text = dataSource[indexPath.row];
    //cell.detailTextLabel.text = detailDataSource[indexPath.row];
    //單一section
    static NSString *requestIdentifier = @"HelloCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:requestIdentifier];
        cell.textLabel.textColor = [UIColor redColor];
    }
    cell.textLabel.text = @"Hello";
    
    
    
    NSString *title;
    switch (indexPath.section) {
        case 0:
            title = @"Download";
            break;
        case 1:
            title = @"Upload";
            break;
            
        default:
            break;
    }
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(230, 10, 80, 40)];
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont fontWithName: @"AvenirNextCondensed-Bold" size: 12.0];
    [button setBackgroundColor:[UIColor yellowColor]];
    button.tag = indexPath.row;
    
    [button addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [cell.contentView addSubview:button];
    
    [button.layer setCornerRadius:10.0f];
    [button.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [button.layer setBorderWidth:2.0f];
    
    
   
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    NSLog(@"You pressed: %ld %ld", indexPath.section, indexPath.row);
    /*
     //不分section累加值
     NSInteger rowNumber = 0;
     
     for (NSInteger i = 0; i < indexPath.section; i++) {
     rowNumber += [self tableView:tableView numberOfRowsInSection:i];
     }
     
     rowNumber += indexPath.row;
     return rowNumber;
     NSLog(@"%ld",rowNumber);
     */
    
}

@end
