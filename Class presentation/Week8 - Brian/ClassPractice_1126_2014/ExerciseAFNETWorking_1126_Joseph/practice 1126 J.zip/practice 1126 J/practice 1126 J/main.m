//
//  main.m
//  practice 1126 J
//
//  Created by Joseph on 2014/11/26.
//  Copyright (c) 2014年 dosomethingq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
