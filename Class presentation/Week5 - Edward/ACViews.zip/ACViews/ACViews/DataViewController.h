//
//  DataViewController.h
//  ACViews
//
//  Created by Edward Chiang on 2014/11/2.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DataViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *dataLabel;
@property (strong, nonatomic) id dataObject;

@end

