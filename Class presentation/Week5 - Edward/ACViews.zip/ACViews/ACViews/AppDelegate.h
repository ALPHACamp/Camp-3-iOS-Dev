//
//  AppDelegate.h
//  ACViews
//
//  Created by Edward Chiang on 2014/11/2.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

