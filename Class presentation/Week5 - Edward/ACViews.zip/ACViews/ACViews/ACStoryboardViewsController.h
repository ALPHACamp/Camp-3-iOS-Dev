//
//  ACViewsController.h
//  ACViews
//
//  Created by Edward Chiang on 2014/11/2.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "DataViewController.h"

@interface ACStoryboardViewsController : DataViewController

@end
