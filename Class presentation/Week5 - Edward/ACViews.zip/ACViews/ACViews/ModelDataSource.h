//
//  ModelController.h
//  ACViews
//
//  Created by Edward Chiang on 2014/11/2.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DataViewController;

@interface ModelDataSource : NSObject <UIPageViewControllerDataSource>

- (DataViewController *)viewControllerAtIndex:(NSUInteger)index storyboard:(UIStoryboard *)storyboard;
- (NSUInteger)indexOfViewController:(DataViewController *)viewController;

@end

