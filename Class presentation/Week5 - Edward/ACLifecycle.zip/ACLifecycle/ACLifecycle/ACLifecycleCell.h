//
//  ACLifecycleCell.h
//  ACLifecycle
//
//  Created by Edward Chiang on 2014/11/5.
//  Copyright (c) 2014年 Soleil Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACLifecycleCell : UITableViewCell

@end
