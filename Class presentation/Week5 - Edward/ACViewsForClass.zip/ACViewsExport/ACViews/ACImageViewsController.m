//
//  ACImageViewsController.m
//  ACViews
//
//  Created by Edward Chiang on 2014/11/2.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACImageViewsController.h"
#import "UIView+LayoutHelper.h"

@interface ACImageViewsController ()

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIImageView *firstImageView;
@property (weak, nonatomic) IBOutlet UIImageView *secondeImageView;

@property (nonatomic, strong) UIImageView *thirdImageView;
@property (nonatomic, strong) UIImageView *forthImageView;

@end

@implementation ACImageViewsController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  
  CGFloat imageViewBetweenMargin = self.secondeImageView.top - self.firstImageView.bottom;
  
  // First contentMode use scale fill
  // Second contentMode use aspect fit
  
  _thirdImageView = [UIImageView createInView:self.scrollView];
  self.thirdImageView.frame = self.secondeImageView.frame;
  self.thirdImageView.backgroundColor = [UIColor orangeColor];
  self.thirdImageView.contentMode = UIViewContentModeScaleAspectFill;
  [self.thirdImageView behine:self.secondeImageView top:imageViewBetweenMargin];
  self.thirdImageView.clipsToBounds = YES;
  self.thirdImageView.image = [UIImage imageNamed:@"HawaiiUS"];
  
  _forthImageView = [UIImageView createInView:self.scrollView];
  self.forthImageView.frame = CGRectMake(self.scrollView.center.x - 240 / 2, 0, 240, 400);
  self.forthImageView.backgroundColor = [UIColor greenColor];
  self.forthImageView.contentMode = UIViewContentModeCenter;
  [self.forthImageView behine:self.thirdImageView top:imageViewBetweenMargin];
  self.forthImageView.image = [UIImage imageNamed:@"HawaiiUS"];
  
  self.scrollView.contentSize = CGSizeMake(self.scrollView.width, self.forthImageView.bottom + imageViewBetweenMargin);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
