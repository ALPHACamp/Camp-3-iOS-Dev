//
//  ACViewsController.m
//  ACViews
//
//  Created by Edward Chiang on 2014/11/2.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACStoryboardViewsController.h"

@interface ACStoryboardViewsController () <
  UITextFieldDelegate
>

@property (weak, nonatomic) IBOutlet UILabel *myLabel;
@property (weak, nonatomic) IBOutlet UIButton *myButton;
@property (weak, nonatomic) IBOutlet UIButton *mySecondButton;
@property (weak, nonatomic) IBOutlet UISegmentedControl *mySegmentedControl;
@property (weak, nonatomic) IBOutlet UITextField *myTextField;
@property (weak, nonatomic) IBOutlet UISlider *mySlider;
@property (weak, nonatomic) IBOutlet UISwitch *mySwitch;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *myActivityIndicatorView;
@property (weak, nonatomic) IBOutlet UIProgressView *myProgressView;

@end

@implementation ACStoryboardViewsController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

  self.myLabel.textColor = [UIColor brownColor];
  
  [self.myButton addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
  
  [self.mySecondButton addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
  
  if (self.mySegmentedControl.numberOfSegments > 1) {
    self.mySegmentedControl.selectedSegmentIndex = 1;
  }
  
  self.myTextField.delegate = self;
  
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Storyboard events

- (IBAction)sliderValueChanged:(id)sender {
  UISlider *currentSlider = (UISlider *)sender;
  [self.myProgressView setProgress:currentSlider.value animated:YES];
}

- (IBAction)segmentedControlValueChanged:(id)sender {
  UISwitch *currentSwich = (UISwitch *)sender;
  if (currentSwich.on) {
    [self.myProgressView setProgress:0.5f animated:YES];
    [self.myActivityIndicatorView startAnimating];
  } else {
    [self.myProgressView setProgress:0.0f animated:YES];
    [self.myActivityIndicatorView stopAnimating];
  }
  self.mySlider.enabled = currentSwich.on;
}

#pragma mark - private

- (void)buttonPressed:(id)sender {
  UIButton *pressedButton = (UIButton *)sender;
  self.myLabel.text = pressedButton.titleLabel.text;
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
  
  [textField resignFirstResponder];
  
  return YES;
}

@end
