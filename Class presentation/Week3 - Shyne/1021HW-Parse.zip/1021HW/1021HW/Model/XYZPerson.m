//
//  XYZPerson.m
//  1021HW
//
//  Created by Joseph on 2014/10/21.
//  Copyright (c) 2014年 dosomethingq. All rights reserved.
//

#import "XYZPerson.h"

@interface XYZPerson  ()

@end


@implementation XYZPerson


- (NSString *) firstName {
    return self.personObject[@"firstName"];
}

- (void) setFirstName:(NSString *)firstName {
    self.personObject[@"firstName"] = firstName;
    [self.personObject saveInBackground];
}

- (NSString *) lastName {
    return self.personObject[@"lastName"];
}

- (void) setlastName:(NSString *)lastName {
    self.personObject[@"lastName"] = lastName;
    [self.personObject saveInBackground];
}


- (NSString *) idNumber {
    return self.personObject[@"idNumber"];
}

- (void) setIdNumber:(NSString *)idNumber {
    self.personObject[@"idNumber"] = idNumber;
    [self.personObject saveInBackground];
}
@end
