//
//  XYZPerson.h
//  1021HW
//
//  Created by Joseph on 2014/10/21.
//  Copyright (c) 2014年 dosomethingq. All rights reserved.
//

#import <Parse/Parse.h>
#import <Foundation/Foundation.h>

@interface XYZPerson : NSObject


@property (nonatomic) PFObject *personObject;
@property (nonatomic) NSString *firstName;
@property (nonatomic) NSString *lastName;
@property (nonatomic) NSString *idNumber;


@end
