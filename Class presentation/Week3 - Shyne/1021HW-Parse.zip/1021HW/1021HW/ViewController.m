//
//  ViewController.m
//  1021HW
//
//  Created by Joseph on 2014/10/21.
//  Copyright (c) 2014年 dosomethingq. All rights reserved.
//

#import <Parse/Parse.h>

#import "ViewController.h"
#import "Customer.h"
#import "DepositViewController.h"
#import "WithdrawViewController.h"
#import "QueryViewController.h"

@interface ViewController ()


@property (weak, nonatomic) IBOutlet UITextField *FisrtNameTextFild;

@property (weak, nonatomic) IBOutlet UITextField *LastNameTextFild;

@property (weak, nonatomic) IBOutlet UITextField *IDTextFild;



@property (strong, nonatomic) NSMutableArray *customerArray;
@property (strong, nonatomic) NSMutableDictionary *customerDictionary;
@property (strong, nonatomic) NSMutableArray *idNumArray;

@property Customer *currentCustomer ;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSMutableArray *) idNumArray {
    if(!_idNumArray)
        _idNumArray = [@[] mutableCopy];
    return _idNumArray;
}


- (IBAction)AccountCreate:(id)sender {
    
    NSString *firstName = self.FisrtNameTextFild.text ;
    NSString *lastName = self.LastNameTextFild.text ;
    NSString *IDName = self.IDTextFild.text ;
    //把IBOutlet 拉的 textfield 欄位的字，給NSString
    
    
    if(self.customerDictionary[IDName]) {
        
        UIAlertController * alert= [UIAlertController
                                      alertControllerWithTitle:@"Warning"
                                      message:[NSString stringWithFormat:@"%@ %@", IDName,@" exists"]
                                      preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction
                             actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 
                             }];
        [alert addAction:ok]; // add action to uialertcontroller
        
        [self presentViewController:alert animated:YES completion:nil];

    } else {
        
        
        
        Customer *person=[[Customer alloc]init];
        // Customer 繼承 XYZPerson
        
        PFObject *customerObject = [PFObject objectWithClassName:@"Customer"];
        
        //NSMutableDictionary *customerObject = [@{} mutableCopy];
        customerObject[@"firstName"] = firstName;
        customerObject[@"lastName"] = lastName;
        customerObject[@"IDName"] = IDName;
        [customerObject saveInBackground];
        
        
        person.personObject = customerObject;
        
        
        
        
        
        [self.customerArray addObject:person];
        [self.idNumArray addObject:IDName];
        // add object，不單只有firstName,lastName,IDName,還有他 person customer 裡的 method，跟他繼承的東西 ？
        
        
        /*
         self.FisrtNameTextFild.text = @"";
         self.LastNameTextFild.text = @"";
         self.IDTextFild.text = @"";
         */
        //可以把TextFiled hide ， 當button按下去那一個瞬間
        
        
        //[self.customerDictionary setValue:person forKey:IDName]; 兩種寫法
        self.customerDictionary[IDName]=person;
        
        
        NSLog(@"Account created %@ %@" , person.firstName , person.lastName);
        
        [person showBalance];
        
        self.currentCustomer =person;
        //把person object(裡面有customer class , method)給currentCustomer,之後再把self.currentCustomer給BalanceViewController用，這樣BalanceViewController就可以用person 的 object (customer class , method)
        
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Congratulations,Your Account Created"
                                                        message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil,nil];
        [alert show];
        
        
        [self saveData];
    }
}



-(NSMutableDictionary*) customerDictionary {
    if(!_customerDictionary)
        _customerDictionary = [[NSMutableDictionary alloc]init];
    return _customerDictionary;
    
}


-(NSMutableArray*) customerArray{
    
    if(!_customerArray)
        _customerArray = [[NSMutableArray alloc]init];
    
    return _customerArray;
}



-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
//    
//    BalanceViewController* destinationVC = segue.destinationViewController ;
//    
//    // pass info : current customer to BalanceViewController
//    destinationVC.currentCustomer=self.currentCustomer;
//    //BalanceViewController即可用 person's object
 
    
    id vc = segue.destinationViewController;
    
    if( [vc isKindOfClass:[DepositViewController class]]) {
    
        ((DepositViewController *)vc).currentCustomer=self.currentCustomer;
        
    } else if( [vc isKindOfClass:[WithdrawViewController class]] &&
               [vc isKindOfClass:[WithdrawViewController class]]) {
    
        WithdrawViewController* WV = segue.destinationViewController;
        
        WV.currentCustomer=self.currentCustomer;
        
    
    } else if( [vc isKindOfClass:[QueryViewController class]]) {
        
        
        
        
        QueryViewController* QV = segue.destinationViewController;
        
       //QV.currentCustomer=self.currentCustomer;
       //應該不需要做吧
        
        QV.customerDictionary = self.customerDictionary;
        
        
    }
    
}


-(void) loadData {
    NSArray* documentDirectories = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES);
    NSString* documentDirectory = [documentDirectories objectAtIndex:0];
    NSString* fullArchivedFilePath = [documentDirectory stringByAppendingPathComponent:@"data.xyz"];
    
    if( [[NSFileManager defaultManager] fileExistsAtPath:fullArchivedFilePath]) {
        self.idNumArray = [NSKeyedUnarchiver unarchiveObjectWithFile:fullArchivedFilePath];
    }
}

-(void) saveData {
    if(!self.idNumArray || self.idNumArray.count == 0) {
        NSLog(@"nothing to save");
        return;
    }
    
    //write to file
    NSArray* documentDirectories = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES);
    NSString* documentDirectory = [documentDirectories objectAtIndex:0];
    NSString* documentDirectoryFilename = [documentDirectory stringByAppendingPathComponent:@"data.xyz"];
    
    BOOL success = [NSKeyedArchiver archiveRootObject:self.idNumArray toFile:documentDirectoryFilename];
    NSAssert(success, @"archiveRootObject failed");
}

- (void) increaseBalance {
    int bonus = 1000;
    
    for(int i=0;i<self.customerArray.count; i ++) {
        Customer *customer = self.customerArray[i];
        [customer deposit:bonus];
    }
    
    
    for( Customer *customer in self.customerArray)
        [customer deposit:bonus];

}
@end
