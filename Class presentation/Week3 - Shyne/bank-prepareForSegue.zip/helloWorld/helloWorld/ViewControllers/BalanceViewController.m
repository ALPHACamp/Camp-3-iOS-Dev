//
//  BalanceViewController.m
//  helloWorld
//
//  Created by Shyne on 10/20/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import "BalanceViewController.h"

@interface BalanceViewController ()

@property (weak, nonatomic) IBOutlet UITextField *depositAmountTextField;
@property (weak, nonatomic) IBOutlet UITextField *withdrawAmountTextField;
@end

@implementation BalanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)depositButtonPressed:(id)sender {
    
    int amount = [self.depositAmountTextField.text  intValue];
    //Customer * currentCustomer = self.customerDictionary[self.IDTextField.text];
    [self.currentCustomer deposit:amount];
    [self.currentCustomer showBalance];
    
}


- (IBAction)withdrawButtonPressed:(id)sender {
    
    int amount = [self.withdrawAmountTextField.text  intValue];
    //Customer * currentCustomer = self.customerDictionary[self.IDTextField.text];
    [self.currentCustomer withdraw:amount];
    [self.currentCustomer showBalance];
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
