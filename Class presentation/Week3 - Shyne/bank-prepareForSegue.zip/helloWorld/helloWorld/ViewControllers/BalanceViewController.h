//
//  BalanceViewController.h
//  helloWorld
//
//  Created by Shyne on 10/20/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Customer.h"

@interface BalanceViewController : UIViewController
@property Customer *currentCustomer;
@end
