//
//  XYZPerson.m
//  helloWorld
//
//  Created by Shyne on 10/15/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import "XYZPerson.h"


@interface XYZPerson () {

    NSString *_firstName;

}




@end


@implementation XYZPerson



#pragma mark - accessors


- (void)setFirstName:(NSString *)firstName {
    _firstName = [firstName lowercaseString];
}

- (NSString *) firstName {
    return _firstName.uppercaseString;
}


#pragma mark - say methods

- (void) sayHello {
    [self saySomething:@"Hello"];
}

- (void) saySomething:(NSString *) greetings {
    //NSLog(@"%@",greetings);
    
    [self sayThis:greetings andThat:@""];
    
}

- (void) sayThis:(NSString *) greetings1 andThat:(NSString *) greetings2 {
    
    NSLog(@"%@%@",greetings1,greetings2);
    
}


-(void) sayFirstName {
    [self saySomething:self.firstName];
}

@end
