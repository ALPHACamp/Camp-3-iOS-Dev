//
//  AppDelegate.h
//  helloWorld
//
//  Created by Shyne on 10/12/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

