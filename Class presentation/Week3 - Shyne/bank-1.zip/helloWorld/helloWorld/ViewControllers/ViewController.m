//
//  ViewController.m
//  helloWorld
//
//  Created by Shyne on 10/12/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import "ViewController.h"
#import "Customer.h"


@interface ViewController ()

@property NSString *dumpString;

@property (weak, nonatomic) IBOutlet UITextField *firstNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *lastNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *IDTextField;


@property (strong,nonatomic) NSMutableArray *customerArray; // of customers
@property (strong,nonatomic) NSMutableDictionary *customerDictionary; // (idNumber,customer)
@property (weak, nonatomic) IBOutlet UITextField *depositAmountTextField;

@property (weak, nonatomic) IBOutlet UITextField *withdrawAmountTextField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //do something wrong
    
    //[self.navigationController setNavigationBarHidden:YES animated:NO];

}


- (NSMutableArray *) customerArray {
    
    if(!_customerArray)
        _customerArray = [[NSMutableArray alloc] init];
    
    return _customerArray;
}


- (NSMutableDictionary *) customerDictionary {
    
    if(!_customerDictionary)
        _customerDictionary = [[NSMutableDictionary alloc] init];
    return _customerDictionary;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)buttonPressed:(id)sender {
    
    NSString * firstName = self.firstNameTextField.text;
    NSString * lastName = self.lastNameTextField.text;
    NSString * IDNumber = self.IDTextField.text;

    
    Customer *person = [[Customer alloc] init];
    
    person.firstName = firstName;
    person.lastName = lastName;
    person.idNumber = IDNumber;
    
    
    //add person to customerArray
    [self.customerArray addObject:person];
    
    //add person to dictionary
    //[self.customerDictionary setValue:person forKey:IDNumber];
    self.customerDictionary[IDNumber] = person;
    
    
    
    /*
    self.firstNameTextField.text = @"";
    self.lastNameTextField.text = @"";
    self.IDTextField.text = @"";
     */
    
    NSLog(@"Account created: %@ %@",person.firstName, person.lastName);
    
    [person showBalance];
    
}

- (IBAction)depositButtonPressed:(id)sender {
    
    int amount = [self.depositAmountTextField.text  intValue];
    Customer * currentCustomer = self.customerDictionary[self.IDTextField.text];
    [currentCustomer deposit:amount];
    [currentCustomer showBalance];

}


- (IBAction)withdrawButtonPressed:(id)sender {
    
    int amount = [self.withdrawAmountTextField.text  intValue];
    Customer * currentCustomer = self.customerDictionary[self.IDTextField.text];
    [currentCustomer withdraw:amount];
    [currentCustomer showBalance];

    
}







- (IBAction)backToMainViewController:(UIStoryboardSegue *) segue {
    
}

@end
