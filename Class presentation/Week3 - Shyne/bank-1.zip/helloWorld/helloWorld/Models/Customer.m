//
//  Customer.m
//  helloWorld
//
//  Created by Shyne on 10/19/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import "Customer.h"

@interface Customer ()

@property int balance; 

@end



@implementation Customer

- (void)deposit:(int)amount {
    self.balance += amount;
    
    //self.balance = self.balance + amount;
}

- (void)withdraw:(int)amount {
    self.balance -= amount;
}

- (void)showBalance {
    NSLog(@"Balance: %i",self.balance);
}

@end
