//
//  Customer.h
//  helloWorld
//
//  Created by Shyne on 10/19/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import "XYZPerson.h"

@interface Customer : XYZPerson

- (void)deposit:(int)amount;
- (void)withdraw:(int)amount;
- (void)showBalance;

@end
