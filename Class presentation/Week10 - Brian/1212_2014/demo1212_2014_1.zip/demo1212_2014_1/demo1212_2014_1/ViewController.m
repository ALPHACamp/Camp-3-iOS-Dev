//
//  ViewController.m
//  demo1212_2014_1
//
//  Created by Brian on 2014/12/12.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "ViewController.h"
#import <HealthKit/HealthKit.h>

@interface ViewController ()
{
    HKHealthStore *healthStore;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    healthStore = [[HKHealthStore alloc] init];

    if ([HKHealthStore isHealthDataAvailable]) {

        NSSet *writeDataTypes = [self dataTypesToWrite];
        NSSet *readDataTypes = [self dataTypesToRead];

        [healthStore requestAuthorizationToShareTypes:writeDataTypes readTypes:readDataTypes completion:^(BOOL success, NSError *error) {
            if (error) {
                NSLog(@"Error: %@", error);
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self readData];
                });
            }
        }];

    }
}

- (void)readData
{
    NSError *error;

    NSDate *dateOfBirth = [healthStore dateOfBirthWithError:&error];
    if (!dateOfBirth) {
        NSLog(@"讀取生日資料錯誤，請先至 Health App 中填寫資料或是授權讀取");
    } else {
        NSDateFormatter *format = [[NSDateFormatter alloc] init];
        [format setDateFormat:@"西元yyyy年M月d日"];
        NSLog(@"%@", [format stringFromDate:dateOfBirth]);
    }

    HKBiologicalSexObject *sex = [healthStore biologicalSexWithError:&error];
    if (!sex) {
        NSLog(@"讀取性別錯誤，請先至 Health App 中填寫資料或是授權讀取");
    } else {
        switch (sex.biologicalSex) {
            case HKBiologicalSexFemale:
                NSLog(@"我是女性");
                break;

            case HKBiologicalSexMale:
                NSLog(@"我是男性");
                break;

            case HKBiologicalSexNotSet:
                NSLog(@"我尚未設定性別");
                break;
        }
    }

    HKBloodTypeObject *blood = [healthStore bloodTypeWithError:&error];
    if (!blood) {
        NSLog(@"讀取血型錯誤，請先至 Health App 中填寫資料或是授權讀取");
    } else {
        switch (blood.bloodType) {
            case HKBloodTypeABNegative:
                NSLog(@"AB-");
                break;

            case HKBloodTypeABPositive:
                NSLog(@"AB+");
                break;

            case HKBloodTypeANegative:
                NSLog(@"A-");
                break;

            case HKBloodTypeAPositive:
                NSLog(@"A+");
                break;

            case HKBloodTypeBNegative:
                NSLog(@"B-");
                break;

            case HKBloodTypeBPositive:
                NSLog(@"B+");
                break;

            case HKBloodTypeONegative:
                NSLog(@"O-");
                break;

            case HKBloodTypeOPositive:
                NSLog(@"O+");
                break;

            case HKBloodTypeNotSet:
                NSLog(@"血型尚未設定");
                break;
        }
    }
}

// 設定哪些類型的資料要寫入 Health Store
-(NSSet *)dataTypesToWrite {
    return nil;
}

// 設定要從Health Store讀出哪些類型的資料
-(NSSet *)dataTypesToRead {
    return [NSSet setWithObjects:
            [HKCharacteristicType characteristicTypeForIdentifier:HKCharacteristicTypeIdentifierDateOfBirth],
            [HKCharacteristicType characteristicTypeForIdentifier:HKCharacteristicTypeIdentifierBiologicalSex],
            [HKCharacteristicType characteristicTypeForIdentifier:HKCharacteristicTypeIdentifierBloodType],
            nil
            ];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
