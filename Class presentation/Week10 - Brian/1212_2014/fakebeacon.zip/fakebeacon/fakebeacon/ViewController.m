//
//  ViewController.m
//  fakebeacon
//
//  Created by Brian on 2014/12/12.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "ViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController () <CBPeripheralManagerDelegate>
{
    CBPeripheralManager *peripheralManager;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
}

- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral
{
    if (peripheral.state != CBPeripheralManagerStatePoweredOn) {
        NSLog(@"Power is off");
        return;
    }

    NSLog(@"Launch Beacon");
    peripheral.delegate = self;

    NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:@"80152B15-06E5-49DE-B850-7D8E163A62BA"];

    CLBeaconRegion * region = [[CLBeaconRegion alloc] initWithProximityUUID:uuid major:20000 minor:1000 identifier:@"AlphaCamp"];

    NSMutableDictionary *dict = [region peripheralDataWithMeasuredPower:nil];
    [dict setObject:@"AlphaCampClass#3iOS" forKey:CBAdvertisementDataLocalNameKey];

    [peripheral startAdvertising:dict];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
