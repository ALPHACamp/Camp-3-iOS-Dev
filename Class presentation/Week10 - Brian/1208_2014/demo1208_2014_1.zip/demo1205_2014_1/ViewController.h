//
//  ViewController.h
//  demo1205_2014_1
//
//  Created by Brian on 2014/12/5.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSString *str;
    NSString *strt;
}

@end

