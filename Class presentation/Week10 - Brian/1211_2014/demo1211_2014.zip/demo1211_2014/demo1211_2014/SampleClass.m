//
//  SampleClass.m
//  demo1211_2014
//
//  Created by Brian on 2014/12/11.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "SampleClass.h"

@implementation SampleClass

-(void)doSomething
{
    NSLog(@"Doing the job");
    if ([self.boss respondsToSelector:@selector(finish:)]) {
        [self.boss finish:self];
    }
}

@end

