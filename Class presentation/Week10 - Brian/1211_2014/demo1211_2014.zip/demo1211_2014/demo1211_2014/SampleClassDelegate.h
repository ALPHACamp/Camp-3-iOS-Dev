//
//  SampleClassDelegate.h
//  demo1211_2014
//
//  Created by Brian on 2014/12/11.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SampleClass;

@protocol SampleDelegate <NSObject>

@required
-(void) finish:(SampleClass *) sampleClass;

@optional
-(void) printmessage:(SampleClass *)sampleClass;

@end
