//
//  main.m
//  demo1211_2014
//
//  Created by Brian on 2014/12/11.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
