//
//  ViewController.m
//  demo1211_2014
//
//  Created by Brian on 2014/12/11.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "ViewController.h"
#import "SampleClass.h"
#import "AppDelegate.h"

@interface ViewController () <SampleDelegate>
{
    SampleClass *sampleClass;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    sampleClass = [[SampleClass alloc] init];
    sampleClass.boss = self;
    [sampleClass doSomething];

    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app getSystemVersion:@"Hello"];

    // [self testMethod];

    [self performSelector:@selector(testMethod)
               withObject:nil
               afterDelay:5.0];

    [self performSelector:@selector(showTheTime)
               withObject:nil
               afterDelay:3.0];


    NSLog(@"END");
}

- (void)finish:(SampleClass *)sampleClass
{
    NSLog(@"done");
}

- (void)testMethod
{
    NSLog(@"testMethod");
}

- (void)showTheTime
{
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy/MM/dd HH:mm:ss"];
    NSLocale *twLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_TW"];
    [format setLocale:twLocale];

    NSDate *today = [NSDate date];
    NSLog(@"%@", [format stringFromDate:today]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
