//
//  SampleClass.h
//  demo1211_2014
//
//  Created by Brian on 2014/12/11.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SampleClassDelegate.h"

@interface SampleClass : NSObject

@property (nonatomic, assign) id<SampleDelegate> boss;

-(void)doSomething;

@end