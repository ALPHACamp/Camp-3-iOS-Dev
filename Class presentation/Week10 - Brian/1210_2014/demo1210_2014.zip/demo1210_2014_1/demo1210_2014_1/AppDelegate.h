//
//  AppDelegate.h
//  demo1210_2014_1
//
//  Created by Brian on 2014/12/10.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

