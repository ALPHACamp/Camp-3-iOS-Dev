//
//  AppDelegate.h
//  demo_1202_cl
//
//  Created by Cyrilshanway on 2014/12/2.
//  Copyright (c) 2014年 Cyrilshanway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

