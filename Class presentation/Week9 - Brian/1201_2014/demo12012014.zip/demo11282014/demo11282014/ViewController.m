//
//  ViewController.m
//  demo11282014
//
//  Created by Brian on 2014/11/28.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"

#import "Line.h"
#import <MessageUI/MessageUI.h>
#import <MobileCoreServices/UTCoreTypes.h>

@interface ViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UIGestureRecognizerDelegate, UIActionSheetDelegate, MFMailComposeViewControllerDelegate>
{
    CALayer                 *_border;

    UITextField             *memberNameText;
    UITextField             *passwordText;

    IBOutlet UIButton       *loginButton;
    IBOutlet UIButton       *forgetButton;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated
{
    NSLog(@"viewWillAppear");

    // Add bottom line
    _border = [CALayer layer];

    _border.borderColor = [[UIColor colorWithRed:150.0/255.0 green:195.0/255.0 blue:35.0/255.0 alpha:1] CGColor];
    _border.borderWidth = 2;
    CALayer *layer = self.navigationController.navigationBar.layer;
    _border.frame = CGRectMake(0, layer.bounds.size.height, layer.bounds.size.width, 2);
    [layer addSublayer:_border];
}

- (void)viewDidLoad {
    NSLog(@"viewDidLoad");


    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    self.tableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];

    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];

    [loginButton.layer setCornerRadius:5.0f];

    // Init input text field
    memberNameText = [[UITextField alloc]initWithFrame:CGRectMake(40, 0, 275, 40)];
    memberNameText.textColor = [UIColor darkGrayColor];
    memberNameText.delegate = self;
    memberNameText.textAlignment = NSTextAlignmentLeft;
    memberNameText.tag = 101;
    memberNameText.font = [UIFont fontWithName: @"STHeitiTC-Medium" size: 13.0];
    memberNameText.autocapitalizationType = UITextAutocapitalizationTypeNone;
    memberNameText.placeholder = @"Email";

    passwordText = [[UITextField alloc]initWithFrame:CGRectMake(40, 0, 275, 40)];
    passwordText.textColor = [UIColor blackColor];
    passwordText.delegate = self;
    passwordText.textAlignment = NSTextAlignmentLeft;
    [passwordText setSecureTextEntry:YES];
    passwordText.tag = 102;
    passwordText.font = [UIFont fontWithName: @"STHeitiTC-Medium" size: 13.0];
    passwordText.placeholder = @"6-12位英數字，不含標點符號";

    UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    [gestureRecognizer setDelegate:self];

    [self.view addGestureRecognizer:gestureRecognizer];
}

- (void)hideKeyboard
{
    [self.view endEditing:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *requestIdentifier = @"LoginCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:requestIdentifier];

    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:requestIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.textLabel.font  = [UIFont fontWithName: @"STHeitiTC-Medium" size: 14.0];
        cell.detailTextLabel.font = [UIFont fontWithName: @"STHeitiTC-Light" size: 14.0];
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.textLabel.textAlignment = NSTextAlignmentLeft;
        cell.textLabel.textColor = [UIColor colorWithRed:121/255.0 green:121/255.0 blue:121/255.0 alpha:1];
        cell.backgroundColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }

    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"";
            [cell.contentView addSubview:memberNameText];
            break;
        case 1:
            cell.textLabel.text = @"";
            [cell.contentView addSubview:passwordText];
            break;
        default:
            break;
    }

    return cell;
}

- (IBAction)showOption1
{
    // [[UIApplication sharedApplication] showMessage];

    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"請選擇"
                                                             delegate:self
                                                    cancelButtonTitle:@"取消"
                                               destructiveButtonTitle:nil
                                                    otherButtonTitles:@"Email", @"Line", nil];

    actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
    actionSheet.tag = 1;

    [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
}

- (IBAction)showOption2
{
    // [[UIApplication sharedApplication] showMessage];

    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"性別?"
                                                             delegate:self
                                                    cancelButtonTitle:@"取消"
                                               destructiveButtonTitle:nil
                                                    otherButtonTitles:@"男", @"女", nil];

    actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
    actionSheet.tag = 2;

    [actionSheet showInView:[UIApplication sharedApplication].keyWindow];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"You choose %ld in actionsheet %ld", buttonIndex, actionSheet.tag);

    switch (actionSheet.tag) {
        case 1: {
            if (buttonIndex == 0) {
                NSLog(@"Open Mail");
                [self openEmail];
            }
            else {
                [self openLine];
            }
            break;
        }
        case 2: {
            if (buttonIndex == 0) {
                NSLog(@"Choose Male");
            }
            else {
                NSLog(@"Choose Female");
            }

            break;
        }

        default:
            break;
    }
}

- (void)openLine
{
    if (![Line isLineInstalled]) {
        NSLog(@"Line is not installed");
    }
    else {
        UIGraphicsBeginImageContextWithOptions(self.view.frame.size, self.view.opaque, 0.0);

        [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
        UIImage *imageScreen = UIGraphicsGetImageFromCurrentImageContext();

        UIGraphicsEndImageContext();

        NSString *savePath = [NSHomeDirectory() stringByAppendingPathComponent:@"tmp/share.png"];

        BOOL ret = [UIImagePNGRepresentation(imageScreen) writeToFile:savePath atomically:YES];

        // [Line shareText:@"This is Alphacamp"];
        [Line shareImage:imageScreen];
    }
}

- (void)openEmail
{
    NSString *emailTitle = @"Hello";
    NSString *messageBody = [NSString stringWithFormat:@"Test Message"];

    if ([MFMailComposeViewController canSendMail]){
        MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
        mc.mailComposeDelegate = self;

        [mc setSubject:emailTitle];
        [mc setMessageBody:messageBody isHTML:YES];

        // Present mail view controller on screen
        [self presentViewController:mc animated:YES completion:nil];
    }
    else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"測試" message:@"Email 尚未設定" delegate:nil cancelButtonTitle:@"確定" otherButtonTitles: nil];

        [alertView show];
    }
}

- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    NSLog(@"mailComposeController:didFinishWithResult:result:error");

    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }

    [self dismissViewControllerAnimated:YES completion:NULL];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
