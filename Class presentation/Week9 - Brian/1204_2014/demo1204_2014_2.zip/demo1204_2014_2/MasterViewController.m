//
//  MasterViewController.m
//  demo1204_2014_2
//
//  Created by Brian on 2014/12/4.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "MasterViewController.h"
#import "DetailViewController.h"

#import "MBProgressHUD.h"
#import "AFHTTPClient.h"
#import "AFNetworking.h"

@interface MasterViewController () <UITextFieldDelegate, UIGestureRecognizerDelegate>
{
    UITextField  *email;

    MBProgressHUD           *progressHUD;
    NSMutableArray          *_dataSource;
    NSMutableArray          *_imageList;
}

@property NSMutableArray *objects;
@end

@implementation MasterViewController

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.leftBarButtonItem = self.editButtonItem;

    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;

    // Init input text field
    email = [[UITextField alloc]initWithFrame:CGRectMake(130, 0, 180, 40)];
    email.placeholder = @"會員登入帳號";
    email.textColor = [UIColor lightGrayColor];
    email.delegate = self;
    email.textAlignment = NSTextAlignmentRight;
    email.font = [UIFont systemFontOfSize:13];
    email.tag = 101;
    email.keyboardType = UIKeyboardTypeEmailAddress;
    email.autocapitalizationType = UITextAutocapitalizationTypeNone;

    UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    [gestureRecognizer setDelegate:self];
    [self.tableView addGestureRecognizer:gestureRecognizer];


    _dataSource = [NSMutableArray arrayWithCapacity:0];
    _imageList = [NSMutableArray arrayWithCapacity:0];

    [self getImageList];
}

- (void)login
{
    NSLog(@"Start to Login...");
}

- (void)getImageList
{
    [_dataSource removeAllObjects];
    [_imageList removeAllObjects];

    [self initializeProgressHUD:@"載入中..."];

//    NSUserDefaults *defaults =  [NSUserDefaults standardUserDefaults];
//    NSString  *accessToken = [defaults objectForKey:@"Token"];
//
//    if (accessToken == nil) {
//        [self login];
//    }
//  NSString  *UserID =      [defaults objectForKey:@"UserID"];

    NSString  *accessToken = @"A00001";
    NSString  *UserID =      @"14307537";

    AFHTTPClient *httpClient = [[AFHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:@"http://106.187.98.65/"]];
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                            accessToken, @"access_token",
                            UserID,      @"user_id",
                            nil];

    NSMutableURLRequest *request = [httpClient requestWithMethod:@"POST"
                                                            path:@"api/v1/test.php"
                                                      parameters:params];

    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {

        [progressHUD hide:YES];

        NSString *tmp = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];

        // Test Log
        NSLog(@"Response: %@", tmp);

        NSData *jsonData = [tmp dataUsingEncoding:NSUTF8StringEncoding];
        NSError *e;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&e];
        NSArray* listData = [dict objectForKey:@"result"];

        NSString *RC = [NSString stringWithFormat:@"%@",  [dict objectForKey:@"RC"]];
        NSString *RM = [NSString stringWithFormat:@"%@", [dict objectForKey:@"RM"]];

        NSLog(@"RC: %@", RC);
        NSLog(@"RM: %@", RM);

        NSInteger arrayLength = [listData count];

        if (arrayLength == 1) {
            for (int i = 0 ; i < arrayLength; i++) {
                NSDictionary *innerDict = listData[i];
                [_dataSource addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                                        [innerDict objectForKey:@"featured_image"],  @"featured_image",

                                        nil]];

                UIImage *image = [UIImage imageNamed:@"background"];
                [_imageList addObject:image];
            }

            NSLog(@"%@", _dataSource);
            NSLog(@"%@", _imageList);


            for (int i = 0 ; i < [_imageList count]; i++) {
                NSString *urlStr = [_dataSource[i] objectForKey:@"featured_image"];
                NSString *imageRequestURL = [urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                NSURL *imageURL = [NSURL URLWithString:imageRequestURL];

                AFImageRequestOperation* imageOperation = [AFImageRequestOperation imageRequestOperationWithRequest: [NSURLRequest requestWithURL:imageURL] success:^(UIImage *image) {
                    [_imageList setObject:image atIndexedSubscript:i];
                    [self.tableView reloadData];
                }];

                NSOperationQueue* queue = [[NSOperationQueue alloc] init];
                [queue addOperation:imageOperation];
            }
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [progressHUD hide:YES];

        NSString *err = @"請檢查網路連接狀態";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"伺服器連線錯誤" message:err delegate:self cancelButtonTitle:@"關閉" otherButtonTitles:nil];
        [alert show];
    }];
    
    [operation start];
}

- (void)hideKeyboard
{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)insertNewObject:(id)sender {
    if (!self.objects) {
        self.objects = [[NSMutableArray alloc] init];
    }
    [self.objects insertObject:[NSDate date] atIndex:0];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        NSDate *object = self.objects[indexPath.row];
        [[segue destinationViewController] setDetailItem:object];
    }
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//    return self.objects.count;
    return [_dataSource count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

    // NSDate *object = self.objects[indexPath.row];
    // cell.textLabel.text = [object description];
    cell.textLabel.text = @"test";
    cell.imageView.image = _imageList[indexPath.row];

    if (indexPath.row == 9) {
        cell.textLabel.text = @"Email";
        [cell.contentView addSubview:email];
    }

    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.objects removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}

- (void)initializeProgressHUD:(NSString *)msg
{
    if (progressHUD)
        [progressHUD removeFromSuperview];

    progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:progressHUD];
    progressHUD.dimBackground = YES;
    // progressHUD.delegate = self;
    progressHUD.labelText = msg;
    progressHUD.margin = 20.f;
    progressHUD.yOffset = 10.f;
    progressHUD.removeFromSuperViewOnHide = YES;
    [progressHUD show:YES];
}

@end
