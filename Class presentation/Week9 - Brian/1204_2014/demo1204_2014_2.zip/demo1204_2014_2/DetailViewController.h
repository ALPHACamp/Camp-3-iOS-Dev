//
//  DetailViewController.h
//  demo1204_2014_2
//
//  Created by Brian on 2014/12/4.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (strong, nonatomic) id detailItem;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@end

