//
//  ACStringExample.h
//  HWNSObject
//
//  Created by Edward Chiang on 2014/10/27.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ACStringExample : NSObject

- (void)runExample;

@end
