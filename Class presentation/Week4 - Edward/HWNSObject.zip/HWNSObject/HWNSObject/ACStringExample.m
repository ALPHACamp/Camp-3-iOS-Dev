//
//  ACStringExample.m
//  HWNSObject
//
//  Created by Edward Chiang on 2014/10/27.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACStringExample.h"

@implementation ACStringExample

- (void)runExample {
  
  // Creating Strings
  NSString *tempString = @"Contrafibularity";
  
  BOOL same = [@"comparison" isEqualToString:tempString];
  NSLog(@"Comparison is equalto %@ = %@", tempString, same ? @"YES" : @"NO");
  
  BOOL contrafibularityEqualTo = [@"Contrafibularity" isEqualToString:tempString];
  NSLog(@"Contrafibularity is equalto %@ = %@", tempString, contrafibularityEqualTo ? @"YES" : @"NO");
  
  // Variable Strings
  NSString *helloString = @"Hello";
  NSString *helloWorldString = [helloString stringByAppendingString:@", world!"];
  NSLog(@"The word is: %@", helloWorldString);
  
  // NSMutableString
  NSMutableString *helloAppendString = [[NSMutableString alloc] initWithString:@"Hello"];
  [helloAppendString appendString:@", world!"];
  
  NSString *username = @"John";
  NSInteger age = 20;
  int intAge = 20;
  NSNumber *ageNumber = [[NSNumber alloc] initWithInteger:age];
  
  [helloAppendString appendFormat:@" My name is %@, my age is '%li,%li,%i'.", username, (long)ageNumber.integerValue, (long)age, intAge];
  NSLog(@"The appending word is: %@", helloAppendString);
  
  // Strings to Present to the User
  NSString *greeting = NSLocalizedStringFromTable(@"Hello", @"StringExample", @"greetings");
  NSLog(@"Say hi from Strings: %@", greeting);
  
  // Combining and extracting Strings
  NSString *beginning = @"beginning";
  NSString *alphaAndOmega = [beginning stringByAppendingString:@" and end"];
  // alphaAndOmega is @"beginning and end"
  
  NSString *source = @"01234567891234";
  if (source.length >= 4) {
    NSString *firstFour = [source substringToIndex:4];
    NSLog(@"firstFour is %@, the length is %lu.", firstFour, (unsigned long)source.length);
  }
  
  // allButFirstThree is @"3456789"
  if (source.length >= 3) {
    NSString *allButFirstThree = [source substringFromIndex:3];
    NSLog(@"AllButFirstThree is %@, the length is %lu.", allButFirstThree, (unsigned long)source.length);
  }
  
  // NSRange
  NSRange twoToSixRange = NSMakeRange(22, 4);
  NSString *twoToSix = [source substringWithRange:twoToSixRange];
  // twoToSix is @"2345"
  NSLog(@"Two to Six is %@, the length is %lu.", twoToSix, (unsigned long)source.length);
  
  NSArray *split = [source componentsSeparatedByString:@"45"];
  // split contains { @"0123", @"6789" }
  
  // Formatting
  NSString *string1 = [NSString stringWithFormat:@"A string: %@, a float: %1.2f",
                       @"string", 31415.9265];
  // string1 is "A string: string, a float: 31415.93"
  
  NSNumber *number = @1234;
  NSDictionary *dictionary = @{@"date": [NSDate date]};
  NSString *baseString = @"Base string.";
  NSString *string2 = [baseString stringByAppendingFormat:
                       @" A number: %@, a dictionary: %@", number, dictionary];
  // string2 is "Base string. A number: 1234, a dictionary: {date = 2005-10-17 09:02:01 -0700; }"
  
  // Case-Insensitive Search for Prefix and Suffix
  NSString *searchString = @"age";
  
  NSString *beginsTest = @"Agencies";
  NSRange prefixRange = [beginsTest rangeOfString:searchString
                                          options:(NSAnchoredSearch | NSCaseInsensitiveSearch)];
  
  // prefixRange = {0, 3}
  
  NSString *endsTest = @"BRICOLAGE";
  NSRange suffixRange = [endsTest rangeOfString:searchString
                                        options:(NSAnchoredSearch | NSCaseInsensitiveSearch | NSBackwardsSearch)];
  
  // suffixRange = {6, 3}

  // Comparing Strings
  NSString *stringOne = @"string1";
  NSString *stringTwo = @"string2";
  NSComparisonResult result;
  result = [stringOne compare:stringTwo];
  // result = -1 (NSOrderedAscending)
  
  // Compare NSNumericSearch
  NSString *string10 = @"string10";
  result = [string10 compare:string2];
  // result = -1 (NSOrderedAscending)
  
  result = [string10 compare:string2 options:NSNumericSearch];
  // result = 1 (NSOrderedDescending)
  
  // Sorted Array
  NSArray *stringsArray = @[@"String 30",
                            @"String 1",
                            @"string 21",
                            @"String 12",
                            @"String 8",
                            @"string 11",
                            @"String 02"];
  
  NSArray *sortedArray = [stringsArray sortedArrayUsingFunction:finderSortWithLocale
                                                        context:(__bridge void *)([NSLocale currentLocale])];
  NSLog(@"Sorted Array is %@", sortedArray);
  // sortedArray contains { "string 1", "String 02", "String 11", "string 12", "String 21" }
  
  // Sorted Array
  NSArray *stringsOfArray = @[@"Coke",
                            @"Christmas",
                            @"Cancer",
                            @"Cabin",
                            @"Christianity",
                            @"c",
                            @"Cafe"];
  
  NSArray *sortedOfArray = [stringsOfArray sortedArrayUsingFunction:finderSortWithLocale
                                                        context:(__bridge void *)([NSLocale currentLocale])];
  NSLog(@"Sorted of Array is %@", sortedOfArray);
  
  NSSortDescriptor *sorterDescriptor = [[NSSortDescriptor alloc]
                               initWithKey:@"description"
                               ascending:YES
                               selector:@selector(localizedCaseInsensitiveCompare:)];
  NSArray *sortDescriptors = [NSArray arrayWithObject:sorterDescriptor];
  NSMutableArray *mutableArray = [NSMutableArray arrayWithArray:stringsOfArray];
  [mutableArray sortUsingDescriptors:sortDescriptors];
  NSLog(@"Sorted of NSMutableArray is %@", mutableArray);
  
  // Scanner
  NSString *string = @"Product: Acme Potato Peeler; Cost: 0.98 73\n\
  Product: Chef Pierre Pasta Fork; Cost: 0.75 19\n\
  Product: Chef Pierre Colander; Cost: 1.27 2\n";
  
  NSString *PRODUCT = @"Product:";
  NSString *COST = @"Cost:";
  
  NSString *productName;
  float productCost;
  NSInteger productSold;
  
  NSCharacterSet *semicolonSet = [NSCharacterSet characterSetWithCharactersInString:@";"];
  NSScanner *theScanner = [NSScanner scannerWithString:string];
  
  while ([theScanner isAtEnd] == NO)
  {
    if ([theScanner scanString:PRODUCT intoString:NULL] &&
        [theScanner scanUpToCharactersFromSet:semicolonSet
                                   intoString:&productName] &&
        [theScanner scanString:@";" intoString:NULL] &&
        [theScanner scanString:COST intoString:NULL] &&
        [theScanner scanFloat:&productCost] &&
        [theScanner scanInteger:&productSold])
    {
      NSLog(@"Sales of %@: $%1.2f", productName, productCost * productSold);
    }
  }

}

int finderSortWithLocale(id string1, id string2, void *locale)
{
  static NSStringCompareOptions comparisonOptions =
  NSCaseInsensitiveSearch | NSNumericSearch |
  NSWidthInsensitiveSearch | NSForcedOrderingSearch;
  
  NSRange string1Range = NSMakeRange(0, [string1 length]);
  
  return [string1 compare:string2
                  options:comparisonOptions
                    range:string1Range
                   locale:(__bridge NSLocale *)locale];
}

@end
