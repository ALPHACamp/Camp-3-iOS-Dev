//
//  CheckTime.h
//  HWNSObject
//
//  Created by Edward Chiang on 2014/10/26.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CheckTime : NSObject

@property (nonatomic, strong) NSDate *time;
@property (nonatomic, assign) NSInteger position;

@end
