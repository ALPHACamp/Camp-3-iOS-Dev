//
//  CheckTime.m
//  HWNSObject
//
//  Created by Edward Chiang on 2014/10/26.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "CheckTime.h"

@implementation CheckTime

- (instancetype)init {
  self = [super init];
  if (self) {
    
  }
  return self;
}

- (NSString *)description {
  return [NSString stringWithFormat:@"Check in at %@", self.time];
}

@end
