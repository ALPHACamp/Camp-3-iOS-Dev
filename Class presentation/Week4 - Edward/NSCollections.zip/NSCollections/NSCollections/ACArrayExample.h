//
//  ACArrayExample.h
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/28.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ACExample.h"

@interface ACArrayExample : NSObject <ACExample>

@end
