//
//  ACURLExample.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/29.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACURLRequestExample.h"

@interface ACURLRequestExample () <
  NSURLConnectionDelegate
>

@property (nonatomic, strong) NSMutableData *responseData;

@end

@implementation ACURLRequestExample

#define kParseAppId @"MnivABdWOJgIlkG8xKmfFaQjaFVae83Jk4bhX9WA"
#define kParseAPIKey  @"YDxEZfqcP9hiAUitgV5kjsZaEaOJcFiMF2Nm21S7"

// http://data.taipei.gov.tw/opendata/apply/NewDataContent;jsessionid=3A72E7293456D38F190F78FD2EBDC802?oid=683965F5-7E23-4134-ADB1-99C4FB1EA517
#define kOpenDataParkAPI  @"http://data.taipei.gov.tw/opendata/apply/json/NjgzOTY1RjUtN0UyMy00MTM0LUFEQjEtOTlDNEZCMUVBNTE3"

// http://data.taipei.gov.tw/opendata/apply/NewDataContent;jsessionid=3A72E7293456D38F190F78FD2EBDC802?oid=68434B0E-5584-41A8-8BAD-969DEC4FFF1E
#define kOpenDataZooAPI  @"http://data.taipei.gov.tw/opendata/apply/json/Njg0MzRCMEUtNTU4NC00MUE4LThCQUQtOTY5REVDNEZGRjFF"

#define kUserAccount @""
#define kUserPassword  @"$"

- (instancetype)init
{
  self = [super init];
  if (self) {
    _responseData = [[NSMutableData alloc] init];
  }
  return self;
}

- (void)run {
  [self runURLRequest];
  [self runURLRequestWithDelegate];
  [self runURLWithOpenData];
}

- (void)runURLRequestWithDelegate {
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:kOpenDataZooAPI]];
  NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
  [self.responseData setLength:0];
  [connection start];
}

- (void)runURLWithOpenData {
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:kOpenDataParkAPI] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60];
  
  [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
    if (!connectionError) {
      NSError *error = nil;
      NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
      if (!error) {
        NSLog(@"jsonDictionary: %@", jsonDictionary);
      } else {
        NSLog(@"Error with: %@", error);
      }
    } else {
      NSLog(@"Connection with: %@", connectionError);
    }

  }];
}

- (void)runURLRequest {
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"https://api.parse.com/1/classes/Lecture"] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60];
  
  NSMutableURLRequest *mutableRequest = [request mutableCopy];
  
  [mutableRequest addValue:kParseAppId forHTTPHeaderField:@"X-Parse-Application-Id"];
  [mutableRequest addValue:kParseAPIKey forHTTPHeaderField:@"X-Parse-REST-API-Key"];
  [mutableRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
  [mutableRequest setHTTPMethod:@"GET"];

  [NSURLConnection sendAsynchronousRequest:mutableRequest queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
    NSError *error = nil;
    NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    if (!error) {
      for (NSDictionary *eachItem in [jsonDictionary objectForKey:@"results"]) {
        NSLog(@"Each Item: %@", eachItem);
      }
    } else {
      NSLog(@"Error with: %@", error);
    }
  }];
}

#pragma mark - NSURLConnectionDelegate

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
  
}

- (BOOL)connectionShouldUseCredentialStorage:(NSURLConnection *)connection {
  return YES;
}

- (void)connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
  NSURLCredential *credential = [NSURLCredential credentialWithUser:kUserAccount
                                                           password:kUserPassword persistence:NSURLCredentialPersistenceForSession];
  
  [[challenge sender] useCredential:credential forAuthenticationChallenge:challenge];
}

#pragma mark - NSURLConnectionDataDelegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
  
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
  [self.responseData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
  NSString *responseString = [[NSString alloc] initWithData:self.responseData encoding:NSUTF8StringEncoding];
  NSError *e = nil;
  NSData *jsonData = [responseString dataUsingEncoding:NSUTF8StringEncoding];
  NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData:jsonData options: NSJSONReadingMutableContainers error: &e];
  NSLog(@"jsonDictionary connectionDidFinishLoading: %@", JSON);
}

@end
