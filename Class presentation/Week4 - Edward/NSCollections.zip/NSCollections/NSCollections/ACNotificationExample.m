//
//  ACNotificationExample.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/30.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACNotificationExample.h"
#import "ACEnumerationExample.h"

@implementation ACNotificationExample

#define kNOTIFICATION_RELOAD_DATA @"kNOTIFICATION_RELOAD_DATA"

- (id)init {
  if (self = [super init]) {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadData:) name:kNOTIFICATION_RELOAD_DATA object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserverForName:kNOTIFICATION_RELOAD_DATA object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
      NSLog(@"Reload data from blocks. With notifcation object: %@", note.object);
      if ([((NSObject *)note.object) isKindOfClass:[ACEnumerationExample class]]) {
        ACEnumerationExample *enumExample = (ACEnumerationExample *)note.object;
        [enumExample run];
      }
    }];
  }
  return self;
}

- (void)dealloc {
  [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)run {
  [[NSNotificationCenter defaultCenter] postNotificationName:kNOTIFICATION_RELOAD_DATA object:@"Hi there."];
  
  [[NSNotificationCenter defaultCenter] postNotificationName:kNOTIFICATION_RELOAD_DATA object:[[ACEnumerationExample alloc] init]];
}

- (void)reloadData:(NSNotification *)notification {
  NSLog(@"Reload data from selector. With notifcation object: %@", notification.object);
}

@end
