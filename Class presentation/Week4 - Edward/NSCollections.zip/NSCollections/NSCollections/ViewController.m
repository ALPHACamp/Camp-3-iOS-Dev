//
//  ViewController.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/28.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ViewController.h"
#import "ACArrayExample.h"
#import "ACDictionaryExample.h"
#import "ACCopyingExample.h"
#import "ACEnumerationExample.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIButton *runArrayExampleButton;
@property (strong, nonatomic) IBOutlet UIButton *runDictionaryExampleButton;
@property (strong, nonatomic) IBOutlet UIButton *runDeepCopyButton;
@property (weak, nonatomic) IBOutlet UIButton *runEnumerationButton;

@end

@implementation ViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
  [self.runArrayExampleButton addTarget:self action:@selector(runArrayExampleButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
  
  [self.runDictionaryExampleButton addTarget:self action:@selector(runDictionaryExampleButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
  
  [self.runDeepCopyButton addTarget:self action:@selector(runDeepCopyButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
  
  [self.runEnumerationButton addTarget:self action:@selector(runEnumerationButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

#pragma mark - private

- (void)runArrayExampleButtonPressed:(id)sender {
  id<ACExample> arrayExample = [[ACArrayExample alloc] init];
  [arrayExample run];
}

- (void)runDictionaryExampleButtonPressed:(id)sender {
  id<ACExample> example = [[ACDictionaryExample alloc] init];
  [example run];
}

- (void)runDeepCopyButtonPressed:(id)sender {
  id<ACExample> example = [[ACCopyingExample alloc] init];
  [example run];
}

- (void)runEnumerationButtonPressed:(id)sender {
  id<ACExample> example = [[ACEnumerationExample alloc] init];
  [example run];
}

@end
