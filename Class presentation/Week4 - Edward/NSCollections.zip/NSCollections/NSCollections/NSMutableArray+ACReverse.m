//
//  NSMutableArray+ACReverse.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/29.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "NSMutableArray+ACReverse.h"

@implementation NSMutableArray (ACReverse)

- (void)reverse {
  if ([self count] == 0)
    return;
  NSUInteger i = 0;
  NSUInteger j = [self count] - 1;
  while (i < j) {
    [self exchangeObjectAtIndex:i
              withObjectAtIndex:j];
    
    i++;
    j--;
  }
}

@end
