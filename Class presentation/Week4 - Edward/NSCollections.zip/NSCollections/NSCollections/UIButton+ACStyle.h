//
//  UIButton+ACStyle.h
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/30.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (ACStyle)

-(void)alphaCampStyle;
-(void)alphaCampStyleWithColor:(UIColor*)color highlightColor:(UIColor*)highlightColor;

@end
