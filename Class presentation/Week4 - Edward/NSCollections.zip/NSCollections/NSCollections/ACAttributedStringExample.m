//
//  ACAttributedStringExample.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/31.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACAttributedStringExample.h"
#import "ACAttributedStringViewController.h"
#import "UIColor+ACAdditional.h"

@implementation ACAttributedStringExample

// Try use http://www.lipsum.com/
#define kSTRINGLPSUMEXAMPLE_PART_1 @"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec dignissim vulputate odio, quis imperdiet est commodo quis. Praesent auctor ante eu est ornare semper. Pellentesque sed mollis enim. Nunc feugiat nibh et aliquam sagittis. Integer a vehicula est. Praesent congue risus id laoreet euismod. Proin suscipit finibus augue non laoreet. Aenean ullamcorper tellus lorem, a auctor augue sollicitudin ac. Suspendisse volutpat diam massa, a pellentesque nisl commodo et. Curabitur laoreet eros ut sapien laoreet, id facilisis arcu sodales. Phasellus eget fringilla nisl. Phasellus et ex nisl. Cras cursus, risus congue accumsan ultricies, elit purus tristique diam, ut elementum dolor ex vel ipsum. Alphacamp.tw.\n\n"

#define kSTRINGLPSUMEXAMPLE_PART_2 @"Etiam tincidunt commodo urna, et finibus dui consequat sit amet. In mattis, dolor vitae sagittis ultricies, ligula ligula sollicitudin augue, id pulvinar nunc tortor ac eros. Donec et placerat nulla. Vivamus aliquam odio eu justo aliquam condimentum. Nam orci nibh, efficitur nec ligula ac, convallis sagittis ligula. Nam euismod sapien vel gravida elementum. Mauris quis purus at lacus maximus auctor. Proin efficitur, massa et vehicula suscipit, augue elit vehicula neque, sed posuere ipsum justo vel enim. Quisque lobortis neque nec euismod varius. Praesent lobortis fermentum tortor ac blandit. Suspendisse potenti. Mauris a lectus elementum, ultrices nisi at, varius augue. Aliquam erat volutpat. Vestibulum auctor elit id arcu dapibus, eget sagittis metus maximus.\n\n"

#define kSTRINGLPSUMEXAMPLE_PART_3 @"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris tincidunt tortor id est malesuada, sit amet ullamcorper felis laoreet. Maecenas vitae tortor sodales, euismod neque in, congue nulla. Aenean quis leo vel arcu auctor aliquet sit amet suscipit justo. Cras fringilla turpis tortor. Proin maximus lectus nec ante volutpat, elementum posuere felis euismod. Proin eu lacus ex. Suspendisse sit amet ex quis nisl volutpat ultricies. Nam nisi risus, ornare vel sollicitudin a, maximus quis sapien. Phasellus et pellentesque risus. Nunc efficitur mi tortor. Aliquam ut quam luctus, finibus nulla sed, finibus mauris. Integer sed magna quam.\n\n"

#define kSTRINGLPSUMEXAMPLE_PART_4  @"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum lectus dui, placerat at nunc quis, varius auctor ante. Etiam scelerisque urna viverra lorem viverra, non pellentesque libero tempor. Aenean interdum interdum felis, a sollicitudin felis tempus sit amet. Nulla elementum finibus rhoncus. Integer enim ex, blandit venenatis diam sit amet, convallis pellentesque lorem. Phasellus a magna quam. Proin commodo, nisl sed suscipit convallis, nulla dolor fringilla sapien, quis consectetur mi urna a nisi. Donec vitae cursus sem. Morbi pellentesque auctor ultrices. Etiam sit amet dui suscipit, tempus odio id, suscipit dolor. Duis tincidunt felis in augue dictum, eu sollicitudin orci suscipit. Pellentesque consequat, erat quis consequat porta, erat lacus semper turpis, sed euismod turpis risus at eros. Etiam mollis mauris quis tortor scelerisque placerat. Etiam vestibulum venenatis lectus, ut finibus mi tempus eget. Curabitur venenatis velit fringilla dolor feugiat cursus. Donec varius, ex at bibendum tincidunt, ante enim iaculis ante, pretium vulputate dolor nisi et tortor."

- (void)run {
  NSAttributedString *attributedString;
  attributedString = [self buildAttributedString];
  
  [[NSNotificationCenter defaultCenter] postNotificationName:kNOTIFICATION_ATTRIBUTED_STRING_TEXT_VIEW_SHOW_TEXT object:attributedString];
}

- (NSAttributedString *)buildAttributedString {
  NSMutableAttributedString* attributedString = [[NSMutableAttributedString alloc] initWithString:kSTRINGLPSUMEXAMPLE_PART_1];
  
  [attributedString appendAttributedString:[[NSAttributedString alloc] initWithString: kSTRINGLPSUMEXAMPLE_PART_2]];
  
  [attributedString appendAttributedString:[[NSAttributedString alloc] initWithString: kSTRINGLPSUMEXAMPLE_PART_3]];
  
  [attributedString appendAttributedString:[[NSAttributedString alloc] initWithString: kSTRINGLPSUMEXAMPLE_PART_4]];
  
  // Background Color
  [attributedString addAttribute:NSBackgroundColorAttributeName value:[UIColor yellowColor] range:[attributedString.string rangeOfString:@"Lorem ipsum dolor sit amet"]];
  
  // Foreground Color
  [attributedString addAttribute:NSForegroundColorAttributeName value:[UIColor greenColor] range:[attributedString.string rangeOfString:@"Integer a vehicula est."]];
  
  // Font
  [attributedString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-Bold" size:20.0] range:[attributedString.string rangeOfString:@"Phasellus eget fringilla nisl."]];
  
  // Strike through
  [attributedString addAttribute:NSStrikethroughStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:[attributedString.string rangeOfString:@"Cras cursus"]];
  
  // Link
  NSURL *linkURL = [NSURL URLWithString:@"http://alphacamp.tw"];
  [attributedString addAttribute:NSLinkAttributeName value:linkURL range:[attributedString.string rangeOfString:@"Alphacamp.tw"]];
  
  //  Preferred Font UIFontTextStyleHeadline
  [attributedString addAttribute:NSFontAttributeName value:[UIFont preferredFontForTextStyle:UIFontTextStyleHeadline] range:[attributedString.string rangeOfString:@"Praesent congue risus id laoreet euismod"]];
  
  //  Preferred Font UIFontTextStyleSubheadline
  [attributedString addAttribute:NSFontAttributeName value:[UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline] range:[attributedString.string rangeOfString:@"Etiam tincidunt commodo urna"]];
  
  // Foreground Color
  [attributedString addAttribute:NSForegroundColorAttributeName value:[UIColor androidGreenColor] range:[attributedString.string rangeOfString:@"Etiam tincidunt commodo urna"]];
  
  NSRange changeFontAndColorRange = [attributedString.string rangeOfString:@"Class aptent taciti sociosqu ad litora torquent per conubia nostra"];
  
  //  Preferred Font
  [attributedString addAttribute:NSFontAttributeName value:[UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline] range:changeFontAndColorRange];
  
  // Foreground Color
  [attributedString addAttribute:NSForegroundColorAttributeName value:[UIColor pinkColor] range:changeFontAndColorRange];
  
  NSDictionary *attributeDictionary = [attributedString attributesAtIndex:changeFontAndColorRange.location effectiveRange:&changeFontAndColorRange];
  
  NSLog(@"AttributeDictionary: %@", attributeDictionary);
  
  // Get Bold body font
  // This will do the best it can to give you a bold version of the UIFontTextStyleBody preferred font. It may or may not actually be bold.
  UIFont *bodyFont = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
  UIFontDescriptor *existingDescriptor = [bodyFont fontDescriptor];
  UIFontDescriptorSymbolicTraits traits = existingDescriptor.symbolicTraits;
  traits |= UIFontDescriptorTraitBold;
  UIFontDescriptor *newDescriptor = [existingDescriptor fontDescriptorWithSymbolicTraits:traits];
  UIFont *boldBodyFont = [UIFont fontWithDescriptor:newDescriptor size:0];
  
  [attributedString addAttribute:NSFontAttributeName value:boldBodyFont range:[attributedString.string rangeOfString:@"finibus mauris. Integer sed magna quam."]];
  
  return attributedString;
}

@end
