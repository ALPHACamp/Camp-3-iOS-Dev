//
//  ACAttributedStringViewController.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/30.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACAttributedStringViewController.h"
#import "ACAttributedStringExample.h"

@interface ACAttributedStringViewController () <
  UITextViewDelegate
>

@property (weak, nonatomic) IBOutlet UIBarButtonItem *cancelButtonItem;
@property (nonatomic, strong) UITextView *textView;

@end

@implementation ACAttributedStringViewController

- (instancetype)init
{
  self = [super init];
  if (self) {
    NSLog(@"From init.");
  }
  return self;
}

- (void)awakeFromNib {
  NSLog(@"From Storyboard awake From Nib.");
}

- (void)viewDidLoad {
  [super viewDidLoad];
  
  self.cancelButtonItem.target = self;
  self.cancelButtonItem.action = @selector(cancelButtonItemPressed:);
  
  _textView = [[UITextView alloc] init];
  [self.view addSubview:self.textView];
  
  self.textView.frame = self.view.frame;
  self.textView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
  self.textView.backgroundColor = [UIColor colorWithRed:0.996 green:0.969 blue:0.882 alpha:1];
  
  self.textView.delegate = self;
  self.textView.editable = NO;
  
  __block ACAttributedStringViewController *__self = self;
  [[NSNotificationCenter defaultCenter] addObserverForName:kNOTIFICATION_ATTRIBUTED_STRING_TEXT_VIEW_SHOW_TEXT object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
    if ([((NSObject *)note.object) isKindOfClass:[NSAttributedString class]]) {
      NSAttributedString *attributedString = note.object;
      __self.textView.attributedText = attributedString;
      
    }
  }];
}

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];
  
  id<ACExample> attributedStringExample = [[ACAttributedStringExample alloc] init];
  [attributedStringExample run];
}


#pragma mark - private

- (void)cancelButtonItemPressed:(id)sender {
  [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange {
  
  NSLog(@"NSURL click: %@", URL);
  
  return NO;
}

@end
