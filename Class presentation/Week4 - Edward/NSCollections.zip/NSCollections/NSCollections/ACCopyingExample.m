//
//  ACCopyingExample.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/28.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACCopyingExample.h"

@implementation ACCopyingExample

- (void)run {
  [self shallowCopy];
  [self deepCopy];
}

- (void)shallowCopy {
  NSArray *userArray = @[@"John", @"Marry", @"Peter"];
  NSArray *shallowCopyArray = [userArray copyWithZone:nil];
  
  NSLog(@"shallowCopyArray: %@", shallowCopyArray);
  NSLog(@"Copy objects are equal: %@", shallowCopyArray == userArray ? @"YES": @"NO");
  
  NSDictionary *userInfoDictionary = @{
                                       @"John" : [NSNumber numberWithInt:18],
                                       @"Marry" : [NSNumber numberWithInt:24],
                                       @"Peter" : [NSNumber numberWithInt:32]
                                       };
  NSDictionary *shallowCopyDict = [[NSDictionary alloc] initWithDictionary:userInfoDictionary copyItems:NO];
  
  NSLog(@"shallowCopyDict: %@", shallowCopyDict);
}

- (void)deepCopy {
  NSArray *userArray = @[@"John", @"Marry", @"Peter"];
  NSArray *deepCopyArray = [[NSArray alloc] initWithArray:userArray copyItems:YES];
  
  NSLog(@"Copy objects are equal: %@", deepCopyArray == userArray ? @"YES": @"NO");
  NSLog(@"deepCopyArray: %@", deepCopyArray);
  
  userArray = @[@"John", @"Marry", @"Peter"];
  NSArray* trueDeepCopyArray = [NSKeyedUnarchiver unarchiveObjectWithData:
                                [NSKeyedArchiver archivedDataWithRootObject:userArray]];

  userArray = nil;
  
  NSLog(@"trueDeepCopyArray: %@", trueDeepCopyArray);

}

@end
