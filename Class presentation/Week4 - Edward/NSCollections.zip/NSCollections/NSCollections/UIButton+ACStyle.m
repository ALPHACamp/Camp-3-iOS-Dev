//
//  UIButton+ACStyle.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/30.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "UIButton+ACStyle.h"
#import "UIImage+Tint.h"
#import "UIImage+ReSize.h"

@implementation UIButton (ACStyle)

-(void)alphaCampStyle
{
  [self alphaCampStyleWithColor:[UIColor colorWithRed:0.906 green:0.416 blue:0.125 alpha:1] highlightColor:[UIColor redColor]];
}

-(void)alphaCampStyleWithColor:(UIColor*)color highlightColor:(UIColor*)highlightColor
{
  UIImage *normalImage = [UIImage imageNamed:@"BackgroundImage"];
  UIImage *resizeImage = [UIImage imageWithImage:normalImage scaledToSize:self.frame.size];
  normalImage = [resizeImage tintedImageWithColor:color];
  UIImage *hightlightImage = [resizeImage tintedImageWithColor:highlightColor];
  [self setBackgroundImage:normalImage forState:UIControlStateNormal];
  [self setBackgroundImage:hightlightImage forState:UIControlStateHighlighted];
  [self setBackgroundImage:hightlightImage forState:UIControlStateSelected];
  [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
  [self setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
  
}


@end
