//
//  ACArrayExample.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/28.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACArrayExample.h"
#import <UIKit/UIKit.h>

@implementation ACArrayExample

#define kSortFirstName  @"firstName"
#define kSortLastName @"lastName"

- (void)run {
  
  [self runMutableArrays];
  [self runSearchingArrays];
  
  //First create the array of dictionaries
  NSString *last = kSortLastName;
  NSString *first = kSortFirstName;
  
  NSMutableArray *array = [NSMutableArray array];
  
  NSDictionary *dict;
  dict = [NSDictionary dictionaryWithObjectsAndKeys:
          @"Jo", first, @"Smith", last, nil];
  [array addObject:dict];
  
  dict = [NSDictionary dictionaryWithObjectsAndKeys:
          @"Joe", first, @"Smith", last, nil];
  [array addObject:dict];
  
  dict = [NSDictionary dictionaryWithObjectsAndKeys:
          @"Joe", first, @"Smythe", last, nil];
  [array addObject:dict];
  
  dict = [NSDictionary dictionaryWithObjectsAndKeys:
          @"Joanne", first, @"Smith", last, nil];
  [array addObject:dict];
  
  dict = [NSDictionary dictionaryWithObjectsAndKeys:
          @"Robert", first, @"Jones", last, nil];
  [array addObject:dict];
  
  [self runSortingArrays:array];
  [self runSortingName:array];
  [self runSortingWithBlocks:@[@10,@24,@56,@23,@45,@74,@64,@33]];
  [self runFilteringArrays];
}

- (void)runMutableArrays {
  // Mutable Arrays
  NSMutableArray *array = [NSMutableArray array];
  [array addObject:[UIColor blackColor]];
  [array insertObject:[UIColor redColor] atIndex:0];
  [array insertObject:[UIColor blueColor] atIndex:1];
  [array addObject:[UIColor whiteColor]];
  [array removeObjectsInRange:(NSMakeRange(1, 2))];
  NSLog(@"Color Aray: %@", array);
}

- (void)runSearchingArrays {
  NSString *yes0 = @"yes";
  NSString *yes1 = @"YES";
  NSString *yes2 = [NSString stringWithFormat:@"%@", yes1];
  
  NSArray *yesArray = [NSArray arrayWithObjects:yes0, yes1, yes2, nil];
  
  NSUInteger index;
  
  index = [yesArray indexOfObject:yes2];
  // index is 1, Returns the lowest index whose corresponding array value is equal to a given object.
  NSLog(@"Yes2 index: %lu", (unsigned long)index);
  
  index = [yesArray indexOfObjectIdenticalTo:yes1];
  // index is 1, Returns the lowest index whose corresponding array value is identical to a given object.
  NSLog(@"Yes1 index: %lu", (unsigned long)index);
  
  index = [yesArray indexOfObjectIdenticalTo:yes2];
  // index is 2, Returns the lowest index whose corresponding array value is identical to a given object.
  NSLog(@"Yes2 index: %lu", (unsigned long)index);
}

- (void)runSortingArrays:(NSArray *)array {
  
  //Next we sort the contents of the array by last name then first name
  
  // The results are likely to be shown to a user
  // Note the use of the localizedCaseInsensitiveCompare: selector
  NSSortDescriptor *lastDescriptor =
  [[NSSortDescriptor alloc] initWithKey:kSortLastName
                              ascending:YES
                               selector:@selector(localizedCaseInsensitiveCompare:)];
  NSSortDescriptor *firstDescriptor =
  [[NSSortDescriptor alloc] initWithKey:kSortFirstName
                              ascending:YES
                               selector:@selector(localizedCaseInsensitiveCompare:)];
  
  NSArray *sortedArray;
  NSArray *descriptors = [NSArray arrayWithObjects:lastDescriptor, firstDescriptor, nil];
  sortedArray = [array sortedArrayUsingDescriptors:descriptors];
  
  NSLog(@"runSortingArrays");
  NSLog(@"Original Aray: %@", array);
  NSLog(@"Sorted Aray: %@", sortedArray);
}

- (void)runSortingName:(NSArray *)array {
  
  NSArray *sortedArray;
  BOOL reverseSort = NO;
  sortedArray = [array sortedArrayUsingFunction:lastNameFirstNameSort context:&reverseSort];

  NSLog(@"runSortingName");
  NSLog(@"Original Aray: %@", array);
  NSLog(@"Sorted Aray: %@", sortedArray);
}

- (void)runSortingWithBlocks:(NSArray *)array {
  
  NSArray *sortedArray = [array sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
    
    if ([obj1 integerValue] > [obj2 integerValue]) {
      return NSOrderedDescending;
    }
    
    if ([obj1 integerValue] < [obj2 integerValue]) {
      return NSOrderedAscending;
    }
    return NSOrderedSame;
  }];
  NSLog(@"runSortingWithBlocks");
  NSLog(@"Original Aray: %@", array);
  NSLog(@"Sorted Aray: %@", sortedArray);
}

- (void)runFilteringArrays {
  NSMutableArray *array =
    [NSMutableArray arrayWithArray:@[@"Bill", @"Ben", @"Chris", @"Melissa"]];
  
  NSPredicate *bPredicate =
  [NSPredicate predicateWithFormat:@"SELF beginswith[c] 'b'"];
  NSArray *beginWithB =
  [array filteredArrayUsingPredicate:bPredicate];
  // beginWithB contains { @"Bill", @"Ben" }.
  NSLog(@"Begain with B: %@", beginWithB);
  
  NSPredicate *sPredicate =
  [NSPredicate predicateWithFormat:@"SELF contains[c] 's'"];
  [array filterUsingPredicate:sPredicate];
  // array now contains { @"Chris", @"Melissa" }
  NSLog(@"Array filter using predicate: %@", array);
}

#pragma mark - function

NSInteger lastNameFirstNameSort(id person1, id person2, void *reverse)
{
  NSString *name1 = [person1 valueForKey:kSortLastName];
  NSString *name2 = [person2 valueForKey:kSortLastName];
  
  NSComparisonResult comparison = [name1 localizedCaseInsensitiveCompare:name2];
  if (comparison == NSOrderedSame) {
    
    name1 = [person1 valueForKey:kSortFirstName];
    name2 = [person2 valueForKey:kSortFirstName];
    comparison = [name1 localizedCaseInsensitiveCompare:name2];
  }
  
  if (*(BOOL *)reverse == YES) {
    return 0 - comparison;
  }
  return comparison;
}



@end
