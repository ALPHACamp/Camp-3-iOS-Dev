//
//  NSArray+ACReverse.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/29.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "NSArray+ACReverse.h"

@implementation NSArray (ACReverse)

- (NSArray *)reversedArray {
  NSMutableArray *array = [NSMutableArray arrayWithCapacity:[self count]];
  NSEnumerator *enumerator = [self reverseObjectEnumerator];
  for (id element in enumerator) {
    [array addObject:element];
  }
  return array;
}

@end
