//
//  ACNotificationExample.h
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/30.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ACExample.h"

@interface ACNotificationExample : NSObject <ACExample>

@end
