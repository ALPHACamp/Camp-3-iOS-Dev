//
//  ACDateExample.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/30.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACDateExample.h"

@implementation ACDateExample

- (void)run {
  [self runCreatingDate];
  [self runCalendarObjects];
  [self runHourFromNow];
  [self runTimeZones];
  [self runDateFormat];
}

- (void)runCreatingDate {
  NSDate *now = [[NSDate alloc] init];
  NSLog(@"Now is %@", now);
  
  // Creating dates with time intervals
  NSTimeInterval secondsPerDay = 24 * 60 * 60;
  NSDate *tomorrow = [[NSDate alloc]
                      initWithTimeIntervalSinceNow:secondsPerDay];
  NSDate *yesterday = [[NSDate alloc]
                       initWithTimeIntervalSinceNow:-secondsPerDay];
  NSLog(@"Tomorrow: %@", tomorrow);
  NSLog(@"Yesterday: %@", yesterday);
  
  // Creating Dates by adding a time interval
  NSDate *today = [[NSDate alloc] init];

  tomorrow = [today dateByAddingTimeInterval: secondsPerDay];
  yesterday = [today dateByAddingTimeInterval: -secondsPerDay];
  NSLog(@"Tomorrow: %@", tomorrow);
  NSLog(@"Yesterday: %@", yesterday);
  
  // Compare
  NSLog(@"Tomorrow vs Yesterday = %@", [tomorrow compare:yesterday] == NSOrderedDescending ? @"NSOrderedDescending" : @"Not NSOrderedDescending");
  
}

- (void)runCalendarObjects {
  
  // Getting a date's components
  NSDate *today = [NSDate date];
  NSCalendar *gregorian = [[NSCalendar alloc]
                           initWithCalendarIdentifier:NSGregorianCalendar];
  NSDateComponents *weekdayComponents =
  [gregorian components:(NSDayCalendarUnit | NSWeekdayCalendarUnit) fromDate:today];
  NSInteger day = [weekdayComponents day];
  NSInteger weekday = [weekdayComponents weekday];
  NSLog(@"Weekday %li, day %li", (long)weekday, (long)day);
  
  // Creating a date from components
  NSDateComponents *components = [[NSDateComponents alloc] init];
  [components setWeekday:2]; // Monday
  [components setWeekdayOrdinal:1]; // The first Monday in the month
  [components setMonth:5]; // May
  [components setYear:2008];
  NSCalendar *gregorianCalendar = [[NSCalendar alloc]
                           initWithCalendarIdentifier:NSGregorianCalendar];
  NSDate *date = [gregorianCalendar dateFromComponents:components];
  NSLog(@"Components date %@", date);
  
  // Creating a yearless date
  components = [[NSDateComponents alloc] init];
  [components setMonth:11];
  [components setDay:7];
  gregorian = [[NSCalendar alloc]
                           initWithCalendarIdentifier:NSGregorianCalendar];
  NSDate *birthday = [gregorian dateFromComponents:components];
  NSLog(@"Components date %@", birthday);
}

- (void)runHourFromNow {
  NSDate *today = [[NSDate alloc] init];
  NSCalendar *gregorian = [[NSCalendar alloc]
                           initWithCalendarIdentifier:NSGregorianCalendar];
  NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
  [offsetComponents setHour:1];
  [offsetComponents setMinute:30];
  // Calculate when, according to Tom Lehrer, World War III will end
  NSDate *moreOneHour = [gregorian dateByAddingComponents:offsetComponents
                                                      toDate:today options:0];
  NSLog(@"One more Hour date %@", moreOneHour);
  
  today = [[NSDate alloc] init];
  gregorian = [[NSCalendar alloc]
                           initWithCalendarIdentifier:NSGregorianCalendar];
  
  // Get the weekday component of the current date
  NSDateComponents *weekdayComponents = [gregorian components:NSWeekdayCalendarUnit
                                                     fromDate:today];
  
  /*
   Create a date components to represent the number of days to subtract from the current date.
   The weekday value for Sunday in the Gregorian calendar is 1, so subtract 1 from the number of days to subtract from the date in question.  (If today is Sunday, subtract 0 days.)
   */
  NSDateComponents *componentsToSubtract = [[NSDateComponents alloc] init];
  [componentsToSubtract setDay: 0 - ([weekdayComponents weekday] - 1)];
  
  NSDate *beginningOfWeek = [gregorian dateByAddingComponents:componentsToSubtract
                                                       toDate:today options:0];
  
  /*
   Optional step:
   beginningOfWeek now has the same hour, minute, and second as the original date (today).
   To normalize to midnight, extract the year, month, and day components and create a new date from those components.
   */
  NSDateComponents *components =
  [gregorian components:(NSYearCalendarUnit | NSMonthCalendarUnit |
                         NSDayCalendarUnit) fromDate: beginningOfWeek];
  beginningOfWeek = [gregorian dateFromComponents:components];
}

- (void)runTimeZones {
  NSArray *timeZoneNames = [NSTimeZone knownTimeZoneNames];

  NSLog(@"Time Zone: %@", timeZoneNames);
  
  NSCalendar *gregorian=[[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
  [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"CDT"]];
  NSDateComponents *timeZoneComps=[[NSDateComponents alloc] init];
  [timeZoneComps setHour:16];
  //specify whatever day, month, and year is appropriate
  NSDate *date=[gregorian dateFromComponents:timeZoneComps];
  
  NSLog(@"CDT date %@", date);
}

- (void)runDateFormat {
  NSDate *today = [NSDate dateWithTimeIntervalSinceNow:0];
  NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
  [dateFormat setDateStyle:NSDateFormatterShortStyle];
  NSString *dateString = [dateFormat stringFromDate:today];
  NSLog(@"Date: %@", dateString);
  
  today = [NSDate date];
  dateFormat = [[NSDateFormatter alloc] init];
  [dateFormat setDateFormat:@"MM/dd/yyyy hh:mma"];
  dateString = [dateFormat stringFromDate:today];
  NSLog(@"date: %@", dateString);

  dateFormat = [[NSDateFormatter alloc] init];
  [dateFormat setDateFormat:@"h:mm a, zzz"];
  dateString = [dateFormat stringFromDate:today];
  NSLog(@"dateString %@", dateString);
  
  NSString *dateStr = @"20141030";
  
  // Convert string to date object
  dateFormat = [[NSDateFormatter alloc] init];
  [dateFormat setDateFormat:@"yyyyMMdd"];
  NSDate *date = [dateFormat dateFromString:dateStr];
  
  // Convert date object to desired output format
  [dateFormat setDateFormat:@"EEEE MMMM d, YYYY"];
  dateStr = [dateFormat stringFromDate:date];
  NSLog(@"dateStr %@", dateStr);
}

@end
