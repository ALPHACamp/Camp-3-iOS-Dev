//
//  ACAttributedStringViewController.h
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/30.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACAttributedStringViewController : UIViewController

@end

#define kNOTIFICATION_ATTRIBUTED_STRING_TEXT_VIEW_SHOW_TEXT @"kNOTIFICATION_ATTRIBUTED_STRING_TEXT_VIEW_SHOW_TEXT"