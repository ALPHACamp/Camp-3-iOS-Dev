//
//  ViewController.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/28.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACViewController.h"
#import "ACArrayExample.h"
#import "ACDictionaryExample.h"
#import "ACCopyingExample.h"
#import "ACEnumerationExample.h"
#import "ACURLRequestExample.h"
#import "ACDateExample.h"
#import "ACNotificationExample.h"
#import "UIButton+ACStyle.h"
#import "ACAttributedStringViewController.h"
#import <CNPGridMenu/CNPGridMenu.h>

@interface ACViewController () <
  CNPGridMenuDelegate
>

@property (weak, nonatomic) IBOutlet UIButton *startANewViewControllerButton;
@property (nonatomic, strong) ACNotificationExample *notficationExample;
@property (weak, nonatomic) IBOutlet UIButton *urlRequestButton;
@property (weak, nonatomic) IBOutlet UIButton *notificationButton;
@property (weak, nonatomic) IBOutlet UIButton *dateButton;
@property (weak, nonatomic) IBOutlet UIButton *enumerationButton;
@property (weak, nonatomic) IBOutlet UIButton *deepCopyButton;
@property (weak, nonatomic) IBOutlet UIButton *dictionaryButton;
@property (weak, nonatomic) IBOutlet UIButton *arrayButton;
@property (weak, nonatomic) IBOutlet UIButton *attributedButton;

@end

@implementation ACViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
  
  _notficationExample = [[ACNotificationExample alloc] init];
  
  [self.arrayButton alphaCampStyle];
  [self.notificationButton alphaCampStyle];
  [self.dateButton alphaCampStyle];
  [self.enumerationButton alphaCampStyle];
  [self.deepCopyButton alphaCampStyle];
  [self.dictionaryButton alphaCampStyle];
  [self.urlRequestButton alphaCampStyle];
  [self.attributedButton alphaCampStyle];
  
  [self.startANewViewControllerButton addTarget:self action:@selector(openInitViewController:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

#pragma mark - private

- (IBAction)runArrayExampleButtonPressed:(id)sender {
  id<ACExample> arrayExample = [[ACArrayExample alloc] init];
  [arrayExample run];
}

- (IBAction)runDictionaryExampleButtonPressed:(id)sender {
  id<ACExample> example = [[ACDictionaryExample alloc] init];
  [example run];
}

- (IBAction)runDeepCopyButtonPressed:(id)sender {
  id<ACExample> example = [[ACCopyingExample alloc] init];
  [example run];
}
- (IBAction)runEnumerationButtonPressed:(id)sender {
  id<ACExample> example = [[ACEnumerationExample alloc] init];
  [example run];
}
- (IBAction)runURLRequestButtonPressed:(id)sender {
  id<ACExample> example = [[ACURLRequestExample alloc] init];
  [example run];
}

- (IBAction)runDateButtonPressed:(id)sender {
  id<ACExample> example = [[ACDateExample alloc] init];
  [example run];
}
- (IBAction)runNotificationButtonPressed:(id)sender {
  [self.notficationExample run];
}

- (void)openInitViewController:(id)sender {
  ACAttributedStringViewController *stringViewController = [[ACAttributedStringViewController alloc] init];
  
  [self.navigationController pushViewController:stringViewController animated:YES];
}

- (IBAction)gridMenuButtonTap:(id)sender {
  CNPGridMenuItem *laterToday = [[CNPGridMenuItem alloc] init];
  laterToday.icon = [UIImage imageNamed:@"LaterToday"];
  laterToday.title = @"Later Today";
  
  CNPGridMenuItem *thisEvening = [[CNPGridMenuItem alloc] init];
  thisEvening.icon = [UIImage imageNamed:@"ThisEvening"];
  thisEvening.title = @"This Evening";
  
  CNPGridMenuItem *tomorrow = [[CNPGridMenuItem alloc] init];
  tomorrow.icon = [UIImage imageNamed:@"Tomorrow"];
  tomorrow.title = @"Tomorrow";
  
  CNPGridMenuItem *thisWeekend = [[CNPGridMenuItem alloc] init];
  thisWeekend.icon = [UIImage imageNamed:@"ThisWeekend"];
  thisWeekend.title = @"This Weekend";
  
  CNPGridMenuItem *nextWeek = [[CNPGridMenuItem alloc] init];
  nextWeek.icon = [UIImage imageNamed:@"NextWeek"];
  nextWeek.title = @"Next Week";
  
  CNPGridMenuItem *inAMonth = [[CNPGridMenuItem alloc] init];
  inAMonth.icon = [UIImage imageNamed:@"InMonth"];
  inAMonth.title = @"In A Month";
  
  CNPGridMenuItem *someday = [[CNPGridMenuItem alloc] init];
  someday.icon = [UIImage imageNamed:@"Someday"];
  someday.title = @"Someday";
  
  CNPGridMenuItem *desktop = [[CNPGridMenuItem alloc] init];
  desktop.icon = [UIImage imageNamed:@"Desktop"];
  desktop.title = @"Desktop";
  
  CNPGridMenuItem *pickDate = [[CNPGridMenuItem alloc] init];
  pickDate.icon = [UIImage imageNamed:@"PickDate"];
  pickDate.title = @"Pick Date";
  
  CNPGridMenu *gridMenu = [[CNPGridMenu alloc] initWithMenuItems:@[laterToday, thisEvening, tomorrow, thisWeekend, nextWeek, inAMonth, someday, desktop, pickDate]];
  gridMenu.delegate = self;
  [self presentGridMenu:gridMenu animated:YES completion:^{
    NSLog(@"Grid Menu Presented");
  }];
}

#pragma mark - CNPGridMenuDelegate

- (void)gridMenuDidTapOnBackground:(CNPGridMenu *)menu {
  [self dismissGridMenuAnimated:YES completion:^{
    NSLog(@"Grid Menu Dismissed With Background Tap");
  }];
}

- (void)gridMenu:(CNPGridMenu *)menu didTapOnItem:(CNPGridMenuItem *)item {
  [self dismissGridMenuAnimated:YES completion:^{
    NSLog(@"Grid Menu Did Tap On Item: %@", item.title);
    
    if ([item.title isEqualToString:@"Tomorrow"]) {
      // Save to tomorrow
    }
  }];
}


@end
