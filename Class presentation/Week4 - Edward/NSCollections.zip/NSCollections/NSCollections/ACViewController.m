//
//  ViewController.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/28.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACViewController.h"
#import "ACArrayExample.h"
#import "ACDictionaryExample.h"
#import "ACCopyingExample.h"
#import "ACEnumerationExample.h"

@interface ACViewController ()

@property (weak, nonatomic) IBOutlet UIButton *runArrayExampleButton;
@property (strong, nonatomic) IBOutlet UIButton *runDictionaryExampleButton;
@property (strong, nonatomic) IBOutlet UIButton *runDeepCopyButton;
@property (weak, nonatomic) IBOutlet UIButton *runEnumerationButton;

@end

@implementation ACViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

#pragma mark - private

- (IBAction)runArrayExampleButtonPressed:(id)sender {
  id<ACExample> arrayExample = [[ACArrayExample alloc] init];
  [arrayExample run];
}

- (IBAction)runDictionaryExampleButtonPressed:(id)sender {
  id<ACExample> example = [[ACDictionaryExample alloc] init];
  [example run];
}

- (IBAction)runDeepCopyButtonPressed:(id)sender {
  id<ACExample> example = [[ACCopyingExample alloc] init];
  [example run];
}
- (IBAction)runEnumerationButtonPressed:(id)sender {
  id<ACExample> example = [[ACEnumerationExample alloc] init];
  [example run];
}

@end
