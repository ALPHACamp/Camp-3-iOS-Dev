//
//  ACColorDemoViewController.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/31.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACColorDemoViewController.h"
#import "UIColor+ACAdditional.h"

@interface ACColorDemoViewController () {
  CGFloat distanceHeight;
}

@property (weak, nonatomic) IBOutlet UIView *demoViewOne;
@property (weak, nonatomic) IBOutlet UIView *demoViewTwo;
@property (weak, nonatomic) IBOutlet UIView *demoViewThree;

@property (nonatomic, strong) UIView *demoViewFour;

@end

@implementation ACColorDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  
  distanceHeight = 100;
  
  _demoViewFour = [[UIView alloc] init];
  
  [self.view addSubview:self.demoViewFour];
  
  self.demoViewOne.backgroundColor = [UIColor blueColor];
  [self.demoViewTwo setBackgroundColor:[UIColor greenColor]];
  self.demoViewThree.backgroundColor = [UIColor pinkColor];
  
  self.demoViewFour.backgroundColor = [UIColor colorWithRed:1.0 green:0.5 blue:0 alpha:1];
}

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];
  self.demoViewFour.frame = CGRectMake(self.demoViewThree.frame.origin.x, self.demoViewThree.frame.origin.y + self.demoViewThree.frame.size.height + 50, self.demoViewThree.frame.size.width, self.demoViewThree.frame.size.height);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
