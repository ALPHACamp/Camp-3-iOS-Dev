//
//  ACDictionaryExample.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/28.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACDictionaryExample.h"
#import "NSArray+ACReverse.h"
#import "NSMutableArray+ACReverse.h"

@implementation ACDictionaryExample

- (void)run {
  [self runAddingObject];
  [self runEntriesFromAnother];
  [self sortKeysByValue];
  [self sortKeysByValueLiteral];
  [self sortKeysByValueUsingBlocks];
}

- (void)runAddingObject {
  NSString *last = @"lastName";
  NSString *first = @"firstName";
  
  NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                               @"Jo", first, @"Smith", last, nil];
  NSString *middle = @"middleInitial";
  [dict setObject:@"M" forKey:middle];
  
  [dict setObject:@"Black" forKey:last];
  
  NSLog(@"Adding object: %@", dict);
}

- (void)runEntriesFromAnother {
  NSString *last = @"lastName";
  NSString *first = @"firstName";
  NSString *suffix = @"suffix";
  NSString *title = @"title";
  
  NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                               @"Jo", first, @"Smith", last, nil];
  
  NSDictionary *newDict = [NSDictionary dictionaryWithObjectsAndKeys:
                           @"Jones", last, @"Hon.", title, @"J.D.", suffix, nil];
  
  [dict addEntriesFromDictionary: newDict];
  NSLog(@"Entries From Another: %@", dict);
}

- (void)sortKeysByValue {
  NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                        [NSNumber numberWithInt:63], @"Mathematics",
                        [NSNumber numberWithInt:72], @"English",
                        [NSNumber numberWithInt:55], @"History",
                        [NSNumber numberWithInt:49], @"Geography",
                        nil];
  
  NSArray *sortedKeysArray = [dict keysSortedByValueUsingSelector:@selector(compare:)];
  // sortedKeysArray contains: Geography, History, Mathematics, English
  NSLog(@"Sort keys by value: %@", sortedKeysArray);
}

- (void)sortKeysByValueLiteral {
  NSDictionary *dict;
  dict = @{
           @"Mathematics":@63,
           @"English" : @72,
           @"History" : @55,
           @"Geography" : @49
           };
  
  NSArray *sortedKeysArray = [dict keysSortedByValueUsingSelector:@selector(compare:)];
  // sortedKeysArray contains: Geography, History, Mathematics, English
  NSLog(@"Sort literal keys by value: %@", sortedKeysArray);
}

- (void)sortKeysByValueUsingBlocks {
  
  NSDictionary *dict = @{
           @"Mathematics":[NSNumber numberWithInt:63],
           @"English" : [NSNumber numberWithInt:72],
           @"History" : [NSNumber numberWithInt:55],
           @"Geography" : [NSNumber numberWithInt:49]
           };
  
  NSArray *blockSortedKeys = [dict keysSortedByValueUsingComparator: ^(id obj1, id obj2) {
    
    if ([obj1 integerValue] > [obj2 integerValue]) {
      return (NSComparisonResult)NSOrderedDescending;
    }
    
    if ([obj1 integerValue] < [obj2 integerValue]) {
      return (NSComparisonResult)NSOrderedAscending;
    }
    return (NSComparisonResult)NSOrderedSame;
  }];

  NSLog(@"Sort literal keys by blocks: %@", blockSortedKeys);
  
  NSArray *sortedFromHighToLowArray = [blockSortedKeys reversedArray];
  
  NSLog(@"Sort from high to low keys by value: %@", sortedFromHighToLowArray);
}

@end
