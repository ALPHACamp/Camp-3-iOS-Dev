//
//  UIColor+ACAdditional.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/31.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "UIColor+ACAdditional.h"

@implementation UIColor (ACAdditional)

+ (UIColor *)pinkColor {
  return [UIColor colorWithRed:0.976 green:0.000 blue:0.404 alpha:1];
}

+ (UIColor *)androidGreenColor {
  return [UIColor colorWithRed:0.420 green:0.627 blue:0.090 alpha:1];
}

@end
