//
//  ACEnumerationExample.m
//  NSCollections
//
//  Created by Edward Chiang on 2014/10/28.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACEnumerationExample.h"

@implementation ACEnumerationExample

- (void)run {
  [self fastEnumeration];
  [self blockEnumeration];
  [self enumeratingDict];
}

- (void)fastEnumeration {
  
  NSArray *userArray = @[@"John", @"Marry", @"Peter"];
  for (NSString *element in userArray) {
    NSLog(@"element: %@", element);
  }
  
  NSDictionary *userInfoDictionary = @{
                                       @"John" : [NSNumber numberWithInt:18],
                                       @"Marry" : [NSNumber numberWithInt:24],
                                       @"Peter" : [NSNumber numberWithInt:32]
                                       };
  
  NSString *key;
  for (key in userInfoDictionary){
    NSLog(@"Key: %@, Value %@", key, [userInfoDictionary objectForKey: key]);
  }

}

- (void)blockEnumeration {
  NSArray *anArray = [NSArray arrayWithObjects:@"A", @"B", @"D", @"M", nil];
  NSString *string = @"c";
  
  [anArray enumerateObjectsUsingBlock:^(id obj, NSUInteger index, BOOL *stop){
    if ([obj localizedCaseInsensitiveCompare:string] == NSOrderedSame) {
      NSLog(@"Object Found: %@ at index: %lu",obj, (unsigned long)index);
      *stop = YES;
    }
  }];
  
  
  NSSet *aSet = [NSSet setWithObjects: @"X", @"Y", @"Z", @"Pi", nil];
  NSString *aString = @"z";
  
  [aSet enumerateObjectsUsingBlock:^(id obj, BOOL *stop){
    if ([obj localizedCaseInsensitiveCompare:aString]==NSOrderedSame) {
      NSLog(@"Object Found: %@", obj);
      *stop = YES;
    }
  } ];
}

- (void)enumeratingDict {
  
  NSDictionary *userInfoDictionary = @{
                                       @"John" : [NSNumber numberWithInt:18],
                                       @"Marry" : [NSNumber numberWithInt:24],
                                       @"Peter" : [NSNumber numberWithInt:32]
                                       };
  
  NSMutableDictionary *myMutableDictionary = [NSMutableDictionary dictionaryWithDictionary:userInfoDictionary] ;
  NSMutableArray *keysToDeleteArray =
  [NSMutableArray arrayWithCapacity:[myMutableDictionary count]];
  NSString *aKey;
  NSEnumerator *keyEnumerator = [myMutableDictionary keyEnumerator];
  while (aKey = [keyEnumerator nextObject])
  {
    if ( [aKey isEqualToString:@"John" ]) {
      [keysToDeleteArray addObject:aKey];
    }
  }
  [myMutableDictionary removeObjectsForKeys:keysToDeleteArray];
  
  NSLog(@"After remove: %@", myMutableDictionary);
}

@end
