//
//  XYZPerson.h
//  helloWorld
//
//  Created by Shyne on 10/15/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYZPerson : NSObject

@property (nonatomic) NSString *firstName;
@property NSString *lastName;
@property NSNumber *yearOfBirth;

//- (void) calculateAge;

- (void) sayHello;
- (void) saySomething:(NSString *) greetings;
- (void) sayThis:(NSString *) greetings1 andThat:(NSString *) greetings2;
- (void) sayFirstName;
@end
