//
//  ViewController.m
//  helloWorld
//
//  Created by Shyne on 10/12/14.
//  Copyright (c) 2014 shynetseng. All rights reserved.
//

#import "ViewController.h"
#import "XYZPerson.h"


@interface ViewController ()

@property NSString *dumpString;

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;

@property (weak, nonatomic) IBOutlet UILabel *displayLabel;

@property (strong,nonatomic) NSMutableArray *nameArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //do something wrong
    
    //[self.navigationController setNavigationBarHidden:YES animated:NO];

}


- (NSMutableArray *) nameArray {
    
    if(!_nameArray)
        _nameArray = [[NSMutableArray alloc] init];
    
    return _nameArray;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)buttonPressed:(id)sender {
    
    NSString * name = self.nameTextField.text;
    
    self.displayLabel.text = name;
    
    NSLog(@"%@",name);
    
    [self.nameArray addObject:name];
    
    XYZPerson *person = [[XYZPerson alloc] init];
    
    person.firstName = name;
    
    [person sayHello];
    [person sayFirstName];
    [person saySomething:@"abc"];
    
}



- (IBAction)backToMainViewController:(UIStoryboardSegue *) segue {
    
}

@end
