//
//  ACCustomTableViewCell.m
//  ACTableViewController
//
//  Created by Edward Chiang on 2014/11/11.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACCustomTableViewCell.h"

@implementation ACCustomTableViewCell

- (void)awakeFromNib {
    // Initialization code
  self.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
  
  self.detailTextLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
  
  _additionalLabel = [[UILabel alloc] init];
  self.additionalLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
  self.additionalLabel.textColor = [UIColor lightGrayColor];
  [self addSubview:self.additionalLabel];
}

- (void)layoutSubviews {
  [super layoutSubviews];
  
  self.textLabel.frame = CGRectMake(10, 10, CGRectGetWidth(self.frame) - 10 * 2, CGRectGetHeight(self.textLabel.frame));
  
  self.detailTextLabel.frame = CGRectMake(CGRectGetMinX(self.textLabel.frame), CGRectGetMaxY(self.textLabel.frame) + 5, CGRectGetWidth(self.textLabel.frame), CGRectGetHeight(self.textLabel.frame));
  
  self.additionalLabel.frame = CGRectMake(CGRectGetMinX(self.textLabel.frame), CGRectGetMaxY(self.detailTextLabel.frame) + 5, CGRectGetWidth(self.textLabel.frame), CGRectGetHeight(self.textLabel.frame));
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
