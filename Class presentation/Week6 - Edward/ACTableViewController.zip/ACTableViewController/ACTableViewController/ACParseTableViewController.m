//
//  ACParseTableViewController.m
//  ACTableViewController
//
//  Created by Edward Chiang on 2014/11/11.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACParseTableViewController.h"

@interface ACParseTableViewController ()

@property (weak, nonatomic) IBOutlet UIBarButtonItem *barEditButton;
@property (nonatomic, strong) UIRefreshControl *refreshControl;

@end

@implementation ACParseTableViewController

#define kParseAppId @"MnivABdWOJgIlkG8xKmfFaQjaFVae83Jk4bhX9WA"
#define kParseAPIKey  @"YDxEZfqcP9hiAUitgV5kjsZaEaOJcFiMF2Nm21S7"

- (void)awakeFromNib {
  _dataArray = [[NSMutableArray alloc] init];
}

- (void)viewDidLoad {
  [super viewDidLoad];
  
  // Uncomment the following line to preserve selection between presentations.
  // self.clearsSelectionOnViewWillAppear = NO;
  
  // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
  // self.navigationItem.rightBarButtonItem = self.editButtonItem;
  
  self.refreshControl = [[UIRefreshControl alloc] init];
  [self.refreshControl addTarget:self action:@selector(loadObjects) forControlEvents:UIControlEventValueChanged];
  [self.tableView addSubview:self.refreshControl];
  
  [self loadObjects];
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  // Return the number of sections.
  return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  // Return the number of rows in the section.
  return self.dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DefaultTableViewCell" forIndexPath:indexPath];
  
  // Configure the cell...
  NSDictionary *eachDictionaryInfo = [self.dataArray objectAtIndex:indexPath.row];
  
  cell.textLabel.text = [eachDictionaryInfo objectForKey:@"subject"];
  cell.detailTextLabel.text = [(NSObject *)[eachDictionaryInfo objectForKey:@"createdAt"] description];
  
  return cell;
}

// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
  // Return NO if you do not want the specified item to be editable.
  return YES;
}


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
  if (editingStyle == UITableViewCellEditingStyleDelete) {
    [self.dataArray removeObjectAtIndex:indexPath.row];
    
    // Delete the row from the data source
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
  } else if (editingStyle == UITableViewCellEditingStyleInsert) {
    // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
  }
}

// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}


// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
  // Return NO if you do not want the item to be re-orderable.
  return YES;
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma mark - private

- (IBAction)addButtonPressed:(id)sender {
  [self.dataArray addObject:@{@"subject": @"Add new lecture", @"createdAt": [NSDate date]}];
  [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationTop];
}

- (IBAction)editButtonPressed:(id)sender {
  UIBarButtonItem *currentButtonItem = sender;
  [self.tableView setEditing:!self.tableView.editing animated:YES];
}

- (void)loadObjects {
  
  [self.refreshControl beginRefreshing];
  
  NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"https://api.parse.com/1/classes/Lecture"] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60];
  
  NSMutableURLRequest *mutableRequest = [request mutableCopy];
  
  [mutableRequest addValue:kParseAppId forHTTPHeaderField:@"X-Parse-Application-Id"];
  [mutableRequest addValue:kParseAPIKey forHTTPHeaderField:@"X-Parse-REST-API-Key"];
  [mutableRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
  [mutableRequest setHTTPMethod:@"GET"];
  
  __block ACParseTableViewController *__self = self;
  [NSURLConnection sendAsynchronousRequest:mutableRequest queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
    
    [__self.refreshControl endRefreshing];
    
    if (connectionError) {
      NSLog(@"Connection Error: %@", connectionError);
    }
    NSError *error = nil;
    if (data) {
      NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
      if (!error) {
        NSArray *resultsArray = [jsonDictionary objectForKey:@"results"];
        
        [__self.dataArray removeAllObjects];
        [__self.dataArray addObjectsFromArray:resultsArray];
        [__self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationAutomatic];
        
      } else {
        NSLog(@"Error with: %@", error);
      }
    }
    
  }];
}

@end
