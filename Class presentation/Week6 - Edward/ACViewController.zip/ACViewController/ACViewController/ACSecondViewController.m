//
//  SecondViewController.m
//  ACTableViewController
//
//  Created by Edward Chiang on 2014/11/11.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACSecondViewController.h"
#import "ACCustomTableViewCell.h"

@interface ACSecondViewController ()

@end

@implementation ACSecondViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  ACCustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CustomTableViewCell" forIndexPath:indexPath];
  
  // Configure the cell...
  NSDictionary *eachDictionaryInfo = [self.dataArray objectAtIndex:indexPath.row];
  
  cell.textLabel.text = [eachDictionaryInfo objectForKey:@"subject"];
  cell.detailTextLabel.text = [(NSObject *)[eachDictionaryInfo objectForKey:@"createdAt"] description];
  cell.additionalLabel.text = [eachDictionaryInfo objectForKey:@"objectId"];
  
  return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
  return 88.f;
}


@end
