//
//  ACPageViewController.h
//  ACViewController
//
//  Created by Edward Chiang on 2014/11/13.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACPageViewController : UIViewController <
  UIPageViewControllerDataSource
>

@property (nonatomic, strong) UIPageViewController *pageController;

@end
