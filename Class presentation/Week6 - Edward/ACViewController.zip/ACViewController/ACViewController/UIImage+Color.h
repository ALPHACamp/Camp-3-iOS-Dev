//
//  UIImage+Color.h
//  beaverwork-ios
//
//  Created by Edward Chiang on 2014/9/28.
//  Copyright (c) 2014年 Soleil Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Color)

+ (UIImage *)imageWithColor:(UIColor *)color;
+ (UIImage *)imageNamed:(NSString *) name withTintColor: (UIColor *) tintColor;

- (UIImage *)imageWithTintColor: (UIColor *) tintColor;

@end
