//
//  ACCollectionViewCell.m
//  ACViewController
//
//  Created by Edward Chiang on 2014/11/11.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACCollectionViewCell.h"

@class CustomCellBackgroundView;

@interface CustomCellBackgroundView : UIView

@end

@implementation CustomCellBackgroundView

- (void)drawRect:(CGRect)rect
{
  // draw a rounded rect bezier path filled with blue
  CGContextRef aRef = UIGraphicsGetCurrentContext();
  CGContextSaveGState(aRef);
  UIBezierPath *bezierPath = [UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:.0f];
  [bezierPath setLineWidth:5.0f];
  [[UIColor blackColor] setStroke];
  
  UIColor *fillColor = [UIColor colorWithRed:0.529 green:0.808 blue:0.922 alpha:1]; // color equivalent is #87ceeb
  [fillColor setFill];
  
  [bezierPath stroke];
  [bezierPath fill];
  CGContextRestoreGState(aRef);
}
@end

@implementation ACCollectionViewCell

- (void)awakeFromNib {
  // change to our custom selected background view
  CustomCellBackgroundView *backgroundView = [[CustomCellBackgroundView alloc] initWithFrame:CGRectZero];
  self.selectedBackgroundView = backgroundView;
}

@end
