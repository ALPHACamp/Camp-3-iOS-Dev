//
//  ACCollectionViewController.m
//  ACViewController
//
//  Created by Edward Chiang on 2014/11/11.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACCollectionViewController.h"
#import "ACCollectionViewCell.h"
#import "ACCollectionHeaderView.h"

@interface ACCollectionViewController ()

@property (nonatomic, strong) NSMutableArray *dataInfo1;
@property (nonatomic, strong) NSMutableArray *dataInfo2;
@property (nonatomic, strong) NSMutableArray *dataInfo3;
@property (nonatomic, strong) NSDictionary *dataInfoCopy;

@end

@implementation ACCollectionViewController

static NSString * const reuseIdentifier = @"ImageTitleCell";

- (void)awakeFromNib {
  _dataInfo1 = [NSMutableArray arrayWithArray:@[@{@"uiimage" :[UIImage imageNamed:@"icon-list-1"], @"name" : @"list-1"},
                @{@"uiimage" :[UIImage imageNamed:@"icon-list-2"], @"name" : @"list-2"},
                @{@"uiimage" :[UIImage imageNamed:@"icon-sail-boat"], @"name" : @"sail-boat"},
                @{@"uiimage" :[UIImage imageNamed:@"icon-timer"], @"name" : @"timer"},
                @{@"uiimage" :[UIImage imageNamed:@"icon-viking-ship"], @"name" : @"viking-ship"}]
               ];
  
  _dataInfo2 = [NSMutableArray arrayWithArray:@[@{@"uiimage" :[UIImage imageNamed:@"icon-list-1"], @"name" : @"list-1"},
                                                @{@"uiimage" :[UIImage imageNamed:@"icon-list-2"], @"name" : @"list-2"},
                                                @{@"uiimage" :[UIImage imageNamed:@"icon-sail-boat"], @"name" : @"sail-boat"},
                                                @{@"uiimage" :[UIImage imageNamed:@"icon-timer"], @"name" : @"timer"},
                                                @{@"uiimage" :[UIImage imageNamed:@"icon-viking-ship"], @"name" : @"viking-ship"}]
                ];
  
  _dataInfo3 = [NSMutableArray arrayWithArray:@[@{@"uiimage" :[UIImage imageNamed:@"icon-list-1"], @"name" : @"list-1"},
                                                @{@"uiimage" :[UIImage imageNamed:@"icon-list-2"], @"name" : @"list-2"},
                                                @{@"uiimage" :[UIImage imageNamed:@"icon-sail-boat"], @"name" : @"sail-boat"},
                                                @{@"uiimage" :[UIImage imageNamed:@"icon-timer"], @"name" : @"timer"},
                                                @{@"uiimage" :[UIImage imageNamed:@"icon-viking-ship"], @"name" : @"viking-ship"}]
                ];
}

- (void)viewDidLoad {
  [super viewDidLoad];
  
  self.clearsSelectionOnViewWillAppear = NO;
  
  // Do any additional setup after loading the view.
  
  UICollectionViewFlowLayout *collectionViewLayout = (UICollectionViewFlowLayout*)self.collectionView.collectionViewLayout;
  collectionViewLayout.sectionInset = UIEdgeInsetsMake(20, 0, 20, 0);
  
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
  return 3;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
  
  NSInteger numberOfItems = 0;
  switch (section) {
    case 0:
      numberOfItems = self.dataInfo1.count;
      break;
    case 1:
      numberOfItems = self.dataInfo2.count;
      break;
    case 2:
      numberOfItems = self.dataInfo3.count;
      break;
    default:
      break;
  }
  return numberOfItems;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
  ACCollectionViewCell *cell = (ACCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
  
  // Configure the cell
  NSDictionary *currentInfo;
  
  switch (indexPath.section) {
    case 0:
      currentInfo = [self.dataInfo1 objectAtIndex:indexPath.row];
      break;
    case 1:
      currentInfo = [self.dataInfo2 objectAtIndex:indexPath.row];
      break;
    case 2:
      currentInfo = [self.dataInfo3 objectAtIndex:indexPath.row];
      break;
    default:
      break;
  }
  
  
  cell.imageView.image = [currentInfo objectForKey:@"uiimage"];
  cell.textLabel.text = [currentInfo objectForKey:@"name"];
  
  return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
  UICollectionReusableView *reusableview = nil;
  
  if (kind == UICollectionElementKindSectionHeader) {
    ACCollectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView" forIndexPath:indexPath];
    
    headerView.titleLabel.text = [NSString stringWithFormat:@"Group #%li", indexPath.section + 1];
    
    reusableview = headerView;
  }
  
  if (kind == UICollectionElementKindSectionFooter) {
    UICollectionReusableView *footerview = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"FooterView" forIndexPath:indexPath];
    
    reusableview = footerview;
  }
  
  return reusableview;
}

#pragma mark <UICollectionViewDelegate>

// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
  return YES;
}

// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
  return YES;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
}

- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
  return YES;
}
- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
  if ([NSStringFromSelector(action) isEqualToString:@"copy:"]
      || [NSStringFromSelector(action) isEqualToString:@"paste:"])
    return YES;
  
  // Prevent all other actions.
  return YES;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
  NSDictionary *currentInfo;
  NSMutableArray *currentSectionArray;
  
  switch (indexPath.section) {
    case 0:
      currentInfo = [self.dataInfo1 objectAtIndex:indexPath.row];
      currentSectionArray = self.dataInfo1;
      break;
    case 1:
      currentInfo = [self.dataInfo2 objectAtIndex:indexPath.row];
      currentSectionArray = self.dataInfo2;
      break;
    case 2:
      currentInfo = [self.dataInfo3 objectAtIndex:indexPath.row];
      currentSectionArray = self.dataInfo3;
      break;
    default:
      break;
  }
  if ([NSStringFromSelector(action) isEqualToString:@"copy:"]) {
    self.dataInfoCopy = [currentInfo copy];
  } else if ([NSStringFromSelector(action) isEqualToString:@"paste:"]) {
    [currentSectionArray insertObject:self.dataInfoCopy atIndex:indexPath.row];
    [self.collectionView insertItemsAtIndexPaths:@[indexPath]];
  } else if ([NSStringFromSelector(action) isEqualToString:@"cut:"]) {
    self.dataInfoCopy = [currentInfo copy];
    [currentSectionArray removeObjectAtIndex:indexPath.row];
    [self.collectionView deleteItemsAtIndexPaths:@[indexPath]];
  }
}

@end
