//
//  ACPageViewController.m
//  ACViewController
//
//  Created by Edward Chiang on 2014/11/13.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACPageViewController.h"
#import "ACChildViewController.h"
#import "ACChildViewController.h"

@interface ACPageViewController () <
  UIPageViewControllerDataSource
>

@property (nonatomic, strong) NSNumber *pageCount;

@end

@implementation ACPageViewController

- (void)awakeFromNib {
  UIPageControl *pageControl = [UIPageControl appearance];
  pageControl.pageIndicatorTintColor = [UIColor lightGrayColor];
  pageControl.currentPageIndicatorTintColor = [UIColor orangeColor];
  pageControl.backgroundColor = [UIColor brownColor];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  _pageCount = [NSNumber numberWithInt:5];
 
  self.pageController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
  
  self.pageController.dataSource = self;
  self.pageController.view.frame = CGRectMake(CGRectGetMinX(self.view.frame), CGRectGetMinY(self.view.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame) - CGRectGetHeight(self.tabBarController.tabBar.frame));
  
  ACChildViewController *initialViewController = [self viewControllerAtIndex:0];
  
  [self.pageController setViewControllers:@[initialViewController] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
  
  [self addChildViewController:self.pageController];
  [self.view addSubview:self.pageController.view];
  [self.pageController didMoveToParentViewController:self];
  

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - private

- (ACChildViewController *)viewControllerAtIndex:(NSUInteger)index {
  
  ACChildViewController *childViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ChildViewController"];
  childViewController.pageIndex = index;
  
  return childViewController;
  
}

#pragma mark - UIPageViewControllerDataSource

- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController {
  return self.pageCount.integerValue;
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController {
  return 0;
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController {
  
  // Step 1. Found out current page index
  NSUInteger index = ((ACChildViewController*) viewController).pageIndex;
  if ((index == 0) || (index == NSNotFound)) {
    return nil;
  }
  // Step 2. Find last one
  index--;
  // Step 3. Return last one view controller
  return [self viewControllerAtIndex:index];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController {
  // Step 1. Found out current page index
   NSUInteger index = ((ACChildViewController*) viewController).pageIndex;
  // Step 2. Find next one
  index++;
  if (index == NSNotFound || index == self.pageCount.integerValue) {
    return nil;
  }
  // Step 3. Return the next one view controller
  return [self viewControllerAtIndex:index];
}

@end
