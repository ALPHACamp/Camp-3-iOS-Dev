//
//  ACPageViewController.m
//  ACViewController
//
//  Created by Edward Chiang on 2014/11/13.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import "ACPageViewController.h"
#import "ACChildViewController.h"
#import "ACChildViewController.h"

@interface ACPageViewController () <
  UIPageViewControllerDataSource
>

@property (nonatomic, strong) NSNumber *pageCount;

@end

@implementation ACPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  
  _pageCount = [NSNumber numberWithInt:5];
 
  self.pageController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
  
  self.pageController.dataSource = self;
  [[self.pageController view] setFrame:[[self view] bounds]];
  
  ACChildViewController *initialViewController = [self viewControllerAtIndex:0];
  
  [self.pageController setViewControllers:@[initialViewController] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
  
  [self addChildViewController:self.pageController];
  [[self view] addSubview:[self.pageController view]];
  [self.pageController didMoveToParentViewController:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - private

- (ACChildViewController *)viewControllerAtIndex:(NSUInteger)index {
  
  ACChildViewController *childViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ChildViewController"];
  childViewController.pageIndex = index;
  
  return childViewController;
  
}

#pragma mark - UIPageViewControllerDataSource

- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController {
  return self.pageCount.integerValue;
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController {
  return 0;
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController {
  
  NSUInteger index = ((ACChildViewController*) viewController).pageIndex;
  if ((index == 0) || (index == NSNotFound)) {
    return nil;
  }
  
  index--;
  
  return [self viewControllerAtIndex:index];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController {
   NSUInteger index = ((ACChildViewController*) viewController).pageIndex;
  if (index == NSNotFound) {
    return nil;
  }
  
  if (index == self.pageCount.integerValue - 1) {
    return nil;
  }
  
  index++;
  return [self viewControllerAtIndex:index];
}

@end
