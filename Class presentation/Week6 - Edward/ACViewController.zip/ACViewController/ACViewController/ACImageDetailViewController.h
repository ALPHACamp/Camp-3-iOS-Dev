//
//  ACImageDetailViewController.h
//  ACViewController
//
//  Created by Edward Chiang on 2014/11/12.
//  Copyright (c) 2014年 Alpha Camp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACImageDetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (nonatomic, strong) UIImage *image;

@end
