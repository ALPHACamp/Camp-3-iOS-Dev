//
//  UIImage+Color.m
//  beaverwork-ios
//
//  Created by Edward Chiang on 2014/9/28.
//  Copyright (c) 2014年 Soleil Studio. All rights reserved.
//

#import "UIImage+Color.h"

@implementation UIImage (Color)

+ (UIImage *)imageWithColor:(UIColor *)color
{
  CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
  UIGraphicsBeginImageContext(rect.size);
  CGContextRef context = UIGraphicsGetCurrentContext();
  
  CGContextSetFillColorWithColor(context, [color CGColor]);
  CGContextFillRect(context, rect);
  
  UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  
  return image;
}

- (UIImage *)imageWithTintColor: (UIColor *) tintColor {
  
  UIImage *baseImage = self;
  
  CGRect drawRect = CGRectMake(0, 0, baseImage.size.width, baseImage.size.height);
  
  UIGraphicsBeginImageContextWithOptions(baseImage.size, NO, 0);
  CGContextRef context = UIGraphicsGetCurrentContext();
  
  CGContextTranslateCTM(context, 0, baseImage.size.height);
  CGContextScaleCTM(context, 1.0, -1.0);
  
  // draw original image
  CGContextSetBlendMode(context, kCGBlendModeNormal);
  CGContextDrawImage(context, drawRect, baseImage.CGImage);
  
  // draw color atop
  CGContextSetFillColorWithColor(context, tintColor.CGColor);
  CGContextSetBlendMode(context, kCGBlendModeSourceAtop);
  CGContextFillRect(context, drawRect);
  
  UIImage *tintedImage = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  
  return tintedImage;
}

+ (UIImage *)imageNamed:(NSString *)name withTintColor: (UIColor *) tintColor {
  
  UIImage *baseImage = [UIImage imageNamed:name];
  
  CGRect drawRect = CGRectMake(0, 0, baseImage.size.width, baseImage.size.height);
  
  UIGraphicsBeginImageContextWithOptions(baseImage.size, NO, 0);
  CGContextRef context = UIGraphicsGetCurrentContext();
  
  CGContextTranslateCTM(context, 0, baseImage.size.height);
  CGContextScaleCTM(context, 1.0, -1.0);
  
  // draw original image
  CGContextSetBlendMode(context, kCGBlendModeNormal);
  CGContextDrawImage(context, drawRect, baseImage.CGImage);
  
  // draw color atop
  CGContextSetFillColorWithColor(context, tintColor.CGColor);
  CGContextSetBlendMode(context, kCGBlendModeSourceAtop);
  CGContextFillRect(context, drawRect);
  
  UIImage *tintedImage = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  
  return tintedImage;
}

@end
