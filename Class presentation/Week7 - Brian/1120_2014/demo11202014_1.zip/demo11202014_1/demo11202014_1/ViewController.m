//
//  ViewController.m
//  demo11202014_1
//
//  Created by Brian on 2014/11/20.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD.h"

@interface ViewController () <UIScrollViewDelegate, UIWebViewDelegate, MBProgressHUDDelegate>
{
    BOOL isShow;
    MBProgressHUD   *progressHUD;
}

@property (weak, nonatomic) IBOutlet UIButton *showButton;
@property (weak, nonatomic) IBOutlet UIScrollView *backgroundScrollView;
@property (weak, nonatomic) IBOutlet UIView *infoView;
@property (weak, nonatomic) IBOutlet UIView *loginView;
@property (weak, nonatomic) IBOutlet UIWebView *webView;


@end

@implementation ViewController


- (IBAction)show:(id)sender
{
    if (self.loginView.hidden == YES) {
        self.loginView.hidden = NO;
    }
    else {
        self.loginView.hidden = YES;
    }

//    if (self.infoView.hidden == YES) {
//        self.infoView.hidden = NO;
//    }
//    else {
//        self.infoView.hidden = YES;
//    }

}
- (IBAction)loginAction:(id)sender
{
    NSLog(@"Login Action");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    self.backgroundScrollView.contentSize = CGSizeMake(320.0f, 900.0f);

    isShow = NO;

    UIButton *OKButton = [[UIButton alloc]initWithFrame:CGRectMake(16,700,30,30)];
    [OKButton addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [OKButton setTitle:@"OK" forState:UIControlStateNormal];
    [OKButton setBackgroundColor:[UIColor redColor]];
    [self.backgroundScrollView addSubview:OKButton];

    UIView *image1 = [[UIView alloc] initWithFrame:CGRectMake(10, 600, 140, 80)];
    image1.backgroundColor = [UIColor blackColor];

    UIView *image2 = [[UIView alloc] initWithFrame:CGRectMake(170, 600, 140, 80)];
    image2.backgroundColor = [UIColor blackColor];

    [self.backgroundScrollView addSubview:image1];
    [self.backgroundScrollView addSubview:image2];

    UIView *image3 = [[UIView alloc] initWithFrame:CGRectMake(10, 690, 140, 80)];
    image3.backgroundColor = [UIColor blackColor];

    UIView *image4 = [[UIView alloc] initWithFrame:CGRectMake(170, 690, 140, 80)];
    image4.backgroundColor = [UIColor blackColor];

    [self.backgroundScrollView addSubview:image3];
    [self.backgroundScrollView addSubview:image4];

    NSMutableArray *imageList = [NSMutableArray arrayWithCapacity:4];

    for (int i = 0 ; i < 4; i++) {

        NSInteger x = -1;
        NSInteger y = 600;

        if( (i % 2) == 0) {
            x = 10;
        }
        else {
            x = 170;
        }

        UIView *image = [[UIView alloc] initWithFrame:CGRectMake(x, y, 140, 80)];
        [imageList addObject:image];
        [self.backgroundScrollView addSubview:image];
    }


    NSURL *url = [NSURL URLWithString:@"http://www.google.com"];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];

    self.webView.delegate = self;
    [self.webView loadRequest:requestObj];

    if (progressHUD)
        [progressHUD removeFromSuperview];

    progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:progressHUD];
    progressHUD.dimBackground = NO;

    progressHUD.dimBackground = YES;
    progressHUD.labelText = @"載入中...";
    progressHUD.margin = 20.f;
    progressHUD.yOffset = 10.f;
    progressHUD.removeFromSuperViewOnHide = YES;
    [progressHUD show:YES];

}

// OKButton's callback
- (void)buttonPressed:(id)sender
{
    NSLog(@"buttonPressed");
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSLog(@"scrollViewDidScroll");
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request
        navigationType:(UIWebViewNavigationType)navigationType
{
    NSLog(@"Raw: %@", request);
    NSString *requestPath = [[request URL] absoluteString];
    NSLog(@"Final: %@", requestPath);

    if ([requestPath rangeOfString:@"ServiceLogin"].location != NSNotFound)
    {
        NSLog(@"Login...");
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:@"登入中..." delegate:self cancelButtonTitle:@"關閉" otherButtonTitles:nil];
        [alert show];
    }
    
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"開始跑");
    [progressHUD show:YES];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSLog(@"結束");
    progressHUD.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
