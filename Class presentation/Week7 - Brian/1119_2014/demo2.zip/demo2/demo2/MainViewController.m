//
//  MainViewController.m
//  demo2
//
//  Created by Brian on 2014/11/19.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "MainViewController.h"
#import "SecondViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    self.title = @"第一頁";
}

- (IBAction)show:(id)sender
{
    SecondViewController *viewController;
    viewController = [[SecondViewController alloc] initWithNibName:@"SecondViewController" bundle:nil];



    [self.navigationController pushViewController:viewController animated:YES];

    viewController.str = @"Sent form Main Controller";    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
