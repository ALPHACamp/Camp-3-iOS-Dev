//
//  SecondViewController.h
//  demo2
//
//  Created by Brian on 2014/11/19.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@property (nonatomic, retain) NSString* str;

@end
