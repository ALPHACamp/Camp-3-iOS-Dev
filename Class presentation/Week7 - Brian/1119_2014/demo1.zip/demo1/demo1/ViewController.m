//
//  ViewController.m
//  demo1
//
//  Created by Brian on 2014/11/19.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated
{

}

- (void)viewDidLoad {
    [super viewDidLoad];

    UIButton *OKButton = [[UIButton alloc]initWithFrame:CGRectMake(16,54,30,30)];
    [OKButton addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [OKButton setTitle:@"OK" forState:UIControlStateNormal];
    [OKButton setBackgroundColor:[UIColor colorWithRed:150.0/255.0 green:195.0/255.0 blue:35.0/255.0 alpha:0.5]];

    [self.view addSubview:OKButton];

    UIButton *CancelButton = [[UIButton alloc]initWithFrame:CGRectMake(56,54,30,30)];
    [CancelButton addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [CancelButton setTitle:NSLocalizedString(@"CANCEL" , @"取消") forState:UIControlStateNormal];
    [CancelButton setBackgroundColor:[UIColor redColor]];

    UIButton *otherButton = [[UIButton alloc]initWithFrame:CGRectMake(120,54,100,30)];
    [otherButton addTarget:self action:@selector(otherPressed:) forControlEvents:UIControlEventTouchUpInside];
    [otherButton setTitle:@"Alert" forState:UIControlStateNormal];
    [otherButton setTitle:@"Unable" forState:UIControlStateDisabled];
    [otherButton setBackgroundImage:[UIImage imageNamed:@"testImage" ] forState:UIControlStateNormal];
    [otherButton setEnabled:NO];

    [self.view addSubview:otherButton];

    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)buttonPressed:(id)sender
{
    NSLog(@"buttonPressed");
}

- (IBAction)otherPressed:(id)sender
{
    NSLog(@"buttonPressed");
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
