//
//  AppDelegate.h
//  demo11212014_1
//
//  Created by Brian on 2014/11/21.
//  Copyright (c) 2014年 alphacamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

